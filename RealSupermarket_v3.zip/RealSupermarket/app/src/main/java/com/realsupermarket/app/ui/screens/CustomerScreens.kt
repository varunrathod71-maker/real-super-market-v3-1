@file:OptIn(ExperimentalMaterial3Api::class)

package com.realsupermarket.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.realsupermarket.app.data.Load
import com.realsupermarket.app.data.OrderStatus
import com.realsupermarket.app.data.OrderWithItems
import com.realsupermarket.app.data.ProductEntity
import com.realsupermarket.app.logic.Money
import com.realsupermarket.app.logic.fmtNum
import com.realsupermarket.app.ui.AppViewModel
import com.realsupermarket.app.ui.components.EmptyState
import com.realsupermarket.app.ui.components.FreeBadge
import com.realsupermarket.app.ui.components.LoadGate
import com.realsupermarket.app.ui.components.LoadingBox
import com.realsupermarket.app.ui.components.OrderCard
import com.realsupermarket.app.ui.components.SecondaryButton
import com.realsupermarket.app.ui.components.ShopCard
import com.realsupermarket.app.ui.components.ShopTopBar
import com.realsupermarket.app.ui.components.chipColors
import com.realsupermarket.app.ui.theme.Muted
import com.realsupermarket.app.ui.theme.RedLight
import com.realsupermarket.app.ui.theme.RedPrimary
import kotlinx.coroutines.launch

@Composable
fun CustomerMain(vm: AppViewModel, onStartOrder: () -> Unit, onOpenOrder: (Long) -> Unit, onLogout: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val snack = remember { SnackbarHostState() }
    val tabs = listOf("Home" to Icons.Filled.Home, "Orders" to Icons.AutoMirrored.Filled.List, "Profile" to Icons.Filled.Person)
    Scaffold(
        topBar = {
            ShopTopBar(title = when (tab) { 0 -> "Real Supermarket"; 1 -> "My Orders"; else -> "My Profile" }) {
                if (tab == 1) {
                    TextButton(onClick = { vm.repo.myOrders.refresh() }) { Text("Refresh", color = Color.White, fontWeight = FontWeight.Bold) }
                }
            }
        },
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icon, contentDescription = label) }, label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White, selectedTextColor = RedPrimary,
                            indicatorColor = RedPrimary, unselectedIconColor = Muted, unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeTab(vm, snack, onStartOrder, onGoOrders = { tab = 1 }, onGoProfile = { tab = 2 }, onOpenOrder = onOpenOrder)
                1 -> OrdersTab(vm, onStartOrder, onOpenOrder)
                else -> ProfileTab(vm, onLogout)
            }
        }
    }
}

@Composable
private fun HomeTab(
    vm: AppViewModel, snack: SnackbarHostState, onStartOrder: () -> Unit,
    onGoOrders: () -> Unit, onGoProfile: () -> Unit, onOpenOrder: (Long) -> Unit
) {
    val user by vm.currentUser.collectAsStateWithLifecycle()
    val productsState by vm.repo.activeProducts.state.collectAsStateWithLifecycle()
    val ordersState by vm.repo.myOrders.state.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var showAbout by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Hello, ${user?.name?.substringBefore(' ') ?: "there"}!", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        Card(
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = RedPrimary),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("Fresh Groceries,\nBetter Life!", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(8.dp))
                Text("Type your grocery list and we'll bring it to your door.", color = Color.White.copy(alpha = 0.92f), fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                FreeBadge()
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = onStartOrder,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp), shape = RoundedCornerShape(28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = RedPrimary)
                ) {
                    Icon(Icons.Filled.ShoppingCart, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Start an Order", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("🛒", "Order Groceries", Modifier.weight(1f), onStartOrder)
            Tile("📦", "My Orders", Modifier.weight(1f), onGoOrders)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("👤", "My Profile", Modifier.weight(1f), onGoProfile)
            Tile("ℹ️", "About Us", Modifier.weight(1f)) { showAbout = true }
        }

        Text("Popular Products", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        when (val ps = productsState) {
            is Load.Loading -> Box(Modifier.fillMaxWidth().height(120.dp)) { LoadingBox() }
            is Load.Failed -> Column {
                Text("Couldn't load products: ${ps.message}", color = Muted)
                TextButton(onClick = { vm.repo.activeProducts.refresh() }) { Text("Retry", color = RedPrimary, fontWeight = FontWeight.Bold) }
            }
            is Load.Ok -> if (ps.data.isEmpty()) {
                Text("No products listed right now. You can still type your own grocery list above.", color = Muted)
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
                    items(ps.data, key = { it.id }) { p ->
                        ProductCard(p) {
                            vm.addProduct(p)
                            scope.launch { snack.showSnackbar("${p.name} added to your list") }
                        }
                    }
                }
            }
        }

        val last = when (val o = ordersState) { is Load.Ok -> o.data.firstOrNull(); else -> null }
        if (last != null) {
            Text("Your Last Order", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            OrderCard(last) { onOpenOrder(last.order.id) }
        }
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false }, containerColor = Color.White,
            title = { Text(settings.shopName, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Shop Smart. Live Better.")
                    Text("Home delivery is always FREE.", fontWeight = FontWeight.SemiBold)
                    if (settings.address.isNotBlank()) Text("Address: ${settings.address}")
                    if (settings.phone.isNotBlank()) Text("Phone: ${settings.phone}")
                }
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Close", color = RedPrimary, fontWeight = FontWeight.Bold) } }
        )
    }
}

@Composable
private fun Tile(emoji: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick, modifier = modifier.heightIn(min = 96.dp), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(Modifier.fillMaxSize().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(emoji, fontSize = 28.sp)
            Spacer(Modifier.height(6.dp))
            Text(label, fontSize = 14.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun ProductCard(p: ProductEntity, onAdd: () -> Unit) {
    Card(
        modifier = Modifier.width(132.dp), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(p.emoji, fontSize = 34.sp)
            Text(p.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 2, minLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            Text("${Money.fmt(p.price)}/${p.unit}", fontSize = 12.sp, color = Muted, maxLines = 1)
            Spacer(Modifier.height(8.dp))
            if (p.stock > 0) {
                Button(
                    onClick = onAdd, modifier = Modifier.fillMaxWidth().height(38.dp), shape = RoundedCornerShape(19.dp),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RedPrimary, contentColor = Color.White)
                ) { Text("Add", fontWeight = FontWeight.Bold) }
            } else {
                Text("Out of stock", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.height(38.dp).padding(top = 9.dp))
            }
        }
    }
}

@Composable
private fun OrdersTab(vm: AppViewModel, onStartOrder: () -> Unit, onOpen: (Long) -> Unit) {
    val state by vm.repo.myOrders.state.collectAsStateWithLifecycle()
    LoadGate(state, onRetry = { vm.repo.myOrders.refresh() }) { all -> OrdersContent(all, onStartOrder, onOpen) }
}

@Composable
private fun OrdersContent(all: List<OrderWithItems>, onStartOrder: () -> Unit, onOpen: (Long) -> Unit) {
    var filter by rememberSaveable { mutableIntStateOf(0) }
    if (all.isEmpty()) {
        EmptyState("📦", "No orders yet", "Your orders will appear here after you place one.", "Start an Order", onStartOrder)
        return
    }
    val shown = when (filter) {
        1 -> all.filter { it.order.status != OrderStatus.DELIVERED.name && it.order.status != OrderStatus.CANCELLED.name }
        2 -> all.filter { it.order.status == OrderStatus.DELIVERED.name }
        else -> all
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "Active", "Delivered").forEachIndexed { i, t ->
                FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(t) }, colors = chipColors())
            }
        }
        if (shown.isEmpty()) {
            EmptyState("🔍", "Nothing here", "No orders match this filter.")
        } else {
            LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(shown, key = { it.order.id }) { o -> OrderCard(o) { onOpen(o.order.id) } }
            }
        }
    }
}

@Composable
private fun ProfileTab(vm: AppViewModel, onLogout: () -> Unit) {
    val user by vm.currentUser.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ShopCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(56.dp).clip(CircleShape).background(RedLight), contentAlignment = Alignment.Center) {
                    Text((user?.name?.firstOrNull() ?: 'U').uppercase(), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = RedPrimary)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(user?.name ?: "", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(user?.phone ?: "", color = Muted)
                }
            }
        }
        ShopCard {
            Text(settings.shopName, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            FreeBadge()
            if (settings.address.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(settings.address, color = Muted) }
            if (settings.phone.isNotBlank()) Text("Phone: ${settings.phone}", color = Muted)
        }
        SecondaryButton("Log out", onLogout)
    }
}
