package com.realsupermarket.app.data

object Role { const val ADMIN = "ADMIN"; const val CUSTOMER = "CUSTOMER"; const val DELIVERY = "DELIVERY" }
object Fulfillment { const val DELIVERY = "DELIVERY"; const val PICKUP = "PICKUP" }
object Payment { const val CASH = "CASH"; const val UPI = "UPI" }

/** Order statuses. The names must match the CHECK constraint in supabase/schema.sql. */
enum class OrderStatus(val label: String) {
    PLACED("Order placed"),
    CONFIRMING("Confirming"),
    CONFIRMED("Confirmed"),
    PREPARING("Preparing"),
    READY("Ready"),
    OUT_FOR_DELIVERY("Out for delivery"),
    DELIVERED("Delivered"),
    CANCELLED("Cancelled");

    companion object {
        fun from(name: String): OrderStatus = entries.firstOrNull { it.name == name } ?: PLACED
    }
}

// These are plain models filled from the Supabase (cloud) database. Nothing here is stored on the phone.
data class UserEntity(val id: String, val name: String, val phone: String, val role: String, val createdAt: Long)

data class ProductEntity(
    val id: Long = 0,
    val name: String,
    val description: String,
    val category: String,
    val price: Double,
    val stock: Double,
    val unit: String,
    val emoji: String,
    val active: Boolean,
    val loose: Boolean
)

data class OrderEntity(
    val id: Long,
    val orderNo: String,
    val userId: String,
    val customerName: String,
    val phone: String,
    val fulfillment: String,
    val address: String,
    val payment: String,
    val paymentConfirmed: Boolean,
    val status: String,
    val subtotal: Double,      // sum of KNOWN item prices only
    val unknownCount: Int,     // items whose price is "to be confirmed"
    val deliveryFee: Double,   // always 0 (enforced by the database)
    val createdAt: Long,
    val deliveryBoyId: String = "",      // "" = nobody assigned yet
    val deliveryBoyName: String = "",
    val deliveryBoyPhone: String = "",
    val deliveredAt: Long = 0L
)

data class OrderItemEntity(
    val id: Long,
    val orderId: Long,
    val name: String,
    val qtyLabel: String,
    val qtyUnknown: Boolean,
    val price: Double?,        // null = customer does not know the price
    val productId: Long?
)

data class OrderWithItems(val order: OrderEntity, val items: List<OrderItemEntity>)

data class ShopSettings(
    val shopName: String = "Real Supermarket",
    val phone: String = "",
    val address: String = "",
    val upiId: String = ""
)

/** One grocery line as submitted by the customer. price == null means "I don't know the price". */
data class OrderLine(val name: String, val qtyLabel: String, val qtyUnknown: Boolean, val price: Double?, val productId: Long?)

data class PlaceOrderRequest(
    val lines: List<OrderLine>,
    val fulfillment: String,
    val name: String,
    val phone: String,
    val address: String,
    val payment: String,
    val clientRef: String
)

sealed interface OrderLookup {
    data object Missing : OrderLookup
    data class Found(val order: OrderWithItems) : OrderLookup
}
