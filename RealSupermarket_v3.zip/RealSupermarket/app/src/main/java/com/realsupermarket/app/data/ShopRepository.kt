package com.realsupermarket.app.data

import com.realsupermarket.app.BuildConfig
import com.realsupermarket.app.logic.Validate
import com.realsupermarket.app.net.ApiException
import com.realsupermarket.app.net.SessionStore
import com.realsupermarket.app.net.SupabaseApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * The single gateway to data. EVERYTHING is read from / written to the shared Supabase database:
 *  - customers only receive their own orders (Row Level Security in the database),
 *  - admin-only actions are refused by the database for anyone who is not an admin.
 * Screens never see JSON or HTTP; they use the Pollers (auto-refreshing cloud reads) and the suspend functions below.
 */
class ShopRepository(private val api: SupabaseApi, private val session: SessionStore, private val scope: CoroutineScope) {
    val configured: Boolean get() = api.configured
    val currentUser: StateFlow<UserEntity?> = session.user

    // ---- cloud reads that refresh themselves while a screen is watching ----
    val activeProducts = Poller(scope) { fetchProducts(onlyActive = true) }
    val myOrders = Poller(scope) { fetchMyOrders() }
    val allOrders = Poller(scope) { fetchAllOrders() }
    val allProducts = Poller(scope) { fetchProducts(onlyActive = false) }
    val customers = Poller(scope) { fetchCustomers() }
    val deliveryBoys = Poller(scope) { fetchDeliveryBoys() }
    val myDeliveries = Poller(scope) { fetchMyDeliveries() }
    val settingsPoller = Poller(scope, 30_000L) { fetchSettings() }

    /** One order (the database only returns it to its owner or to an admin). */
    fun orderPoller(id: Long): Poller<OrderLookup> = Poller(scope, 5000L) { fetchOrder(id) }

    private suspend fun fetchProducts(onlyActive: Boolean): List<ProductEntity> {
        val q = "/rest/v1/products?select=*&order=name.asc" + if (onlyActive) "&active=eq.true" else ""
        return JSONArray(api.get(q)).objects().map { productFrom(it) }
    }

    private suspend fun fetchMyOrders(): List<OrderWithItems> {
        val uid = session.userId ?: throw ApiException("Please log in again.", status = 401)
        val q = "/rest/v1/orders?select=*,order_items(*)&user_id=eq.$uid&order=created_ms.desc&limit=300"
        return JSONArray(api.get(q)).objects().map { orderFrom(it) }
    }

    private suspend fun fetchAllOrders(): List<OrderWithItems> {
        requireAdminUi()
        return JSONArray(api.get("/rest/v1/orders?select=*,order_items(*)&order=created_ms.desc&limit=500")).objects().map { orderFrom(it) }
    }

    private suspend fun fetchCustomers(): List<UserEntity> {
        requireAdminUi()
        return JSONArray(api.get("/rest/v1/profiles?select=*&role=eq.customer&order=created_ms.desc&limit=500")).objects().map { userFrom(it) }
    }

    private suspend fun fetchDeliveryBoys(): List<UserEntity> {
        requireAdminUi()
        return JSONArray(api.get("/rest/v1/profiles?select=*&role=eq.delivery&order=created_ms.desc&limit=200")).objects().map { userFrom(it) }
    }

    /** Orders assigned to the signed-in delivery boy (the database refuses to return anyone else's). */
    private suspend fun fetchMyDeliveries(): List<OrderWithItems> {
        val uid = session.userId ?: throw ApiException("Please log in again.", status = 401)
        if (session.user.value?.role != Role.DELIVERY) throw ApiException("Delivery access required.", status = 403)
        val q = "/rest/v1/orders?select=*,order_items(*)&delivery_boy_id=eq.$uid&order=created_ms.desc&limit=300"
        return JSONArray(api.get(q)).objects().map { orderFrom(it) }
    }

    private suspend fun fetchOrder(id: Long): OrderLookup {
        val rows = JSONArray(api.get("/rest/v1/orders?select=*,order_items(*)&id=eq.$id")).objects()
        return if (rows.isEmpty()) OrderLookup.Missing else OrderLookup.Found(orderFrom(rows[0]))
    }

    private suspend fun fetchSettings(): ShopSettings {
        val m = HashMap<String, String>()
        JSONArray(api.get("/rest/v1/shop_settings?select=*")).objects().forEach { m[it.optString("key")] = it.optString("value") }
        return ShopSettings(m["shop_name"] ?: "Real Supermarket", m["shop_phone"] ?: "", m["shop_address"] ?: "", m["upi_id"] ?: "")
    }

    /** Friendly early check. The REAL protection is the database policy; this just gives a clear message. */
    private fun requireAdminUi() {
        if (session.user.value?.role != Role.ADMIN) throw ApiException("Admin access required.", status = 403)
    }

    // ---------------- accounts (Supabase Auth) ----------------
    /** Customers log in with their mobile number; Supabase Auth needs an email, so we derive one from it. An admin types a real email. */
    private fun emailFor(identifier: String): String {
        val s = identifier.trim().lowercase()
        return if ('@' in s) s else "$s@${BuildConfig.CUSTOMER_EMAIL_DOMAIN}"
    }

    suspend fun register(name: String, phone: String, password: String): UserEntity {
        Validate.name(name)?.let { throw IllegalArgumentException(it) }
        Validate.phone(phone)?.let { throw IllegalArgumentException(it) }
        Validate.password(password)?.let { throw IllegalArgumentException(it) }
        val email = emailFor(phone)
        val body = JSONObject().put("email", email).put("password", password)
            .put("data", JSONObject().put("name", name.trim()).put("phone", phone.trim())).toString()
        val res = JSONObject(api.post("/auth/v1/signup", body, authed = false))
        if (!res.has("access_token")) {
            throw ApiException("Sign-up needs email confirmation. In Supabase, turn OFF Authentication > Sign In / Providers > Email > Confirm email, then try again.")
        }
        val uid = res.optJSONObject("user")?.optString("id")
        session.saveTokens(res.getString("access_token"), res.getString("refresh_token"), res.optLong("expires_in", 3600), uid)
        session.email = email
        return profileOrSignOut()
    }

    suspend fun login(identifier: String, password: String): UserEntity {
        val email = emailFor(identifier)
        val res = JSONObject(api.post("/auth/v1/token?grant_type=password", JSONObject().put("email", email).put("password", password).toString(), authed = false))
        session.saveTokens(res.getString("access_token"), res.getString("refresh_token"), res.optLong("expires_in", 3600), res.getJSONObject("user").getString("id"))
        session.email = email
        return profileOrSignOut()
    }

    private suspend fun profileOrSignOut(): UserEntity {
        try {
            return loadProfile()
        } catch (e: Exception) {
            session.clear()
            throw e
        }
    }

    /** Reads this user's profile (name, phone, role) from the cloud. */
    suspend fun loadProfile(): UserEntity {
        val uid = session.userId ?: throw ApiException("Please log in again.", status = 401)
        val rows = JSONArray(api.get("/rest/v1/profiles?id=eq.$uid&select=*")).objects()
        if (rows.isEmpty()) throw ApiException("Your account profile was not found. Did you run supabase/schema.sql?")
        val u = userFrom(rows[0])
        session.saveUser(u)
        return u
    }

    fun logout() = session.clear()

    suspend fun changePassword(oldPassword: String, newPassword: String) {
        Validate.password(newPassword)?.let { throw IllegalArgumentException(it) }
        val email = session.email ?: throw ApiException("Please log out and log in again, then change the password.")
        try {
            api.post("/auth/v1/token?grant_type=password", JSONObject().put("email", email).put("password", oldPassword).toString(), authed = false)
        } catch (e: ApiException) {
            if (e.offline) throw e
            throw ApiException("Current password is wrong.")
        }
        api.put("/auth/v1/user", JSONObject().put("password", newPassword).toString())
    }

    // ---------------- customer: place order (one atomic call to the database) ----------------
    suspend fun placeOrder(req: PlaceOrderRequest): Long {
        if (req.lines.isEmpty()) throw IllegalArgumentException("Your order is empty. Please add at least one item.")
        Validate.name(req.name)?.let { throw IllegalArgumentException(it) }
        Validate.phone(req.phone)?.let { throw IllegalArgumentException(it) }
        if (req.fulfillment == Fulfillment.DELIVERY) Validate.address(req.address)?.let { throw IllegalArgumentException(it) }
        val items = JSONArray()
        req.lines.forEach { l ->
            if (l.name.isBlank()) throw IllegalArgumentException("An item has no name.")
            if (!l.qtyUnknown && l.qtyLabel.isBlank()) throw IllegalArgumentException("\"${l.name}\" needs a quantity.")
            if (l.price != null && (l.price <= 0.0 || l.price > 100000.0)) throw IllegalArgumentException("\"${l.name}\" has an invalid price.")
            items.put(
                JSONObject().put("name", l.name.trim()).put("qty_label", l.qtyLabel).put("qty_unknown", l.qtyUnknown)
                    .put("price", l.price ?: JSONObject.NULL).put("product_id", l.productId ?: JSONObject.NULL)
            )
        }
        val body = JSONObject()
            .put("p_fulfillment", req.fulfillment).put("p_name", req.name.trim()).put("p_phone", req.phone.trim())
            .put("p_address", req.address.trim()).put("p_payment", req.payment).put("p_client_ref", req.clientRef)
            .put("p_items", items).toString()
        val answer = api.post("/rest/v1/rpc/place_order", body)
        val id = answer.trim().toLongOrNull()
            ?: throw ApiException("The shop returned an unexpected answer. Please check My Orders before trying again.")
        myOrders.refresh()
        activeProducts.refresh()
        return id
    }

    // ---------------- admin operations (the database refuses these for non-admins) ----------------
    private fun requireChanged(answer: String) {
        if (JSONArray(answer).length() == 0) throw ApiException("Not allowed (admin only) or the item no longer exists.", status = 403)
    }

    suspend fun updateStatus(orderId: Long, status: OrderStatus) {
        requireAdminUi()
        requireChanged(api.patch("/rest/v1/orders?id=eq.$orderId", JSONObject().put("status", status.name).toString(), "return=representation"))
        allOrders.refresh()
    }

    suspend fun setPaymentConfirmed(orderId: Long, confirmed: Boolean) {
        requireAdminUi()
        requireChanged(api.patch("/rest/v1/orders?id=eq.$orderId", JSONObject().put("payment_confirmed", confirmed).toString(), "return=representation"))
        allOrders.refresh()
    }

    suspend fun saveProduct(p: ProductEntity) {
        requireAdminUi()
        val j = JSONObject().put("name", p.name).put("description", p.description).put("category", p.category)
            .put("price", p.price).put("stock", p.stock).put("unit", p.unit).put("emoji", p.emoji)
            .put("active", p.active).put("loose", p.loose)
        if (p.id > 0) j.put("id", p.id)
        requireChanged(api.post("/rest/v1/products?on_conflict=id", j.toString(), "resolution=merge-duplicates,return=representation"))
        allProducts.refresh()
        activeProducts.refresh()
    }

    suspend fun deleteProduct(id: Long) {
        requireAdminUi()
        requireChanged(api.delete("/rest/v1/products?id=eq.$id", "return=representation"))
        allProducts.refresh()
        activeProducts.refresh()
    }

    suspend fun saveSettings(s: ShopSettings) {
        requireAdminUi()
        val rows = JSONArray()
            .put(JSONObject().put("key", "shop_name").put("value", s.shopName.trim()))
            .put(JSONObject().put("key", "shop_phone").put("value", s.phone.trim()))
            .put(JSONObject().put("key", "shop_address").put("value", s.address.trim()))
            .put(JSONObject().put("key", "upi_id").put("value", s.upiId.trim()))
        requireChanged(api.post("/rest/v1/shop_settings?on_conflict=key", rows.toString(), "resolution=merge-duplicates,return=representation"))
        settingsPoller.refresh()
    }

    // ---------------- admin: delivery boys ----------------
    /** Creates the login with Supabase Auth, then the admin-only database function turns it into a delivery boy. */
    suspend fun addDeliveryBoy(name: String, phone: String, password: String) {
        requireAdminUi()
        Validate.name(name)?.let { throw IllegalArgumentException(it) }
        Validate.phone(phone)?.let { throw IllegalArgumentException(it) }
        Validate.password(password)?.let { throw IllegalArgumentException(it) }
        val body = JSONObject().put("email", emailFor(phone)).put("password", password)
            .put("data", JSONObject().put("name", name.trim()).put("phone", phone.trim())).toString()
        // authed = false: this must NOT replace the admin's own login session
        val res = JSONObject(api.post("/auth/v1/signup", body, authed = false))
        val id = res.optJSONObject("user")?.optString("id").orEmpty().ifBlank { res.optString("id") }
        if (id.isBlank()) {
            throw ApiException("The account could not be created. In Supabase, turn OFF Authentication > Sign In / Providers > Email > Confirm email, then try again.")
        }
        api.post("/rest/v1/rpc/set_user_role", JSONObject().put("p_user", id).put("p_role", "delivery").toString())
        deliveryBoys.refresh()
    }

    suspend fun removeDeliveryBoy(id: String) {
        requireAdminUi()
        api.post("/rest/v1/rpc/set_user_role", JSONObject().put("p_user", id).put("p_role", "customer").toString())
        deliveryBoys.refresh()
        allOrders.refresh()
    }

    /** boy == null un-assigns the order. */
    suspend fun assignDelivery(orderId: Long, boy: UserEntity?) {
        requireAdminUi()
        val j = JSONObject()
            .put("delivery_boy_id", boy?.id ?: JSONObject.NULL)
            .put("delivery_boy_name", boy?.name ?: "")
            .put("delivery_boy_phone", boy?.phone ?: "")
        requireChanged(api.patch("/rest/v1/orders?id=eq.$orderId", j.toString(), "return=representation"))
        allOrders.refresh()
    }

    // ---------------- delivery boy (the database only lets him touch his own orders) ----------------
    private fun requireDeliveryUi() {
        if (session.user.value?.role != Role.DELIVERY) throw ApiException("Delivery access required.", status = 403)
    }

    suspend fun startDelivery(orderId: Long) {
        requireDeliveryUi()
        api.post("/rest/v1/rpc/delivery_update_order",
            JSONObject().put("p_order_id", orderId).put("p_status", OrderStatus.OUT_FOR_DELIVERY.name).toString())
        myDeliveries.refresh()
    }

    suspend fun finishDelivery(orderId: Long, cashCollected: Boolean) {
        requireDeliveryUi()
        api.post("/rest/v1/rpc/delivery_update_order",
            JSONObject().put("p_order_id", orderId).put("p_status", OrderStatus.DELIVERED.name)
                .put("p_cash_collected", cashCollected).toString())
        myDeliveries.refresh()
    }
}
