@file:OptIn(ExperimentalMaterial3Api::class)

package com.realsupermarket.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.realsupermarket.app.data.Fulfillment
import com.realsupermarket.app.data.OrderLookup
import com.realsupermarket.app.data.OrderStatus
import com.realsupermarket.app.data.OrderWithItems
import com.realsupermarket.app.data.Payment
import com.realsupermarket.app.logic.DateFmt
import com.realsupermarket.app.logic.Money
import com.realsupermarket.app.logic.Validate
import com.realsupermarket.app.ui.AppViewModel
import com.realsupermarket.app.ui.components.BottomAction
import com.realsupermarket.app.ui.components.EmptyState
import com.realsupermarket.app.ui.components.FreeBadge
import com.realsupermarket.app.ui.components.InfoRow
import com.realsupermarket.app.ui.components.LoadGate
import com.realsupermarket.app.ui.components.PrimaryButton
import com.realsupermarket.app.ui.components.SecondaryButton
import com.realsupermarket.app.ui.components.ShopCard
import com.realsupermarket.app.ui.components.ShopField
import com.realsupermarket.app.ui.components.ShopTopBar
import com.realsupermarket.app.ui.theme.GreenBg
import com.realsupermarket.app.ui.theme.GreenOk
import com.realsupermarket.app.ui.theme.Muted
import com.realsupermarket.app.ui.theme.RedLight
import com.realsupermarket.app.ui.theme.RedPrimary
import com.realsupermarket.app.ui.theme.Warn

@Composable
private fun ChoiceCard(selected: Boolean, title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) RedLight else Color.White),
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) RedPrimary else Color(0xFFE0D6D6))
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = selected, onClick = null, colors = RadioButtonDefaults.colors(selectedColor = RedPrimary))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(subtitle, fontSize = 13.sp, color = Muted)
            }
        }
    }
}

@Composable
fun CheckoutScreen(vm: AppViewModel, onBack: () -> Unit, onPlaced: (Long) -> Unit) {
    val user by vm.currentUser.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var fulfillment by rememberSaveable { mutableStateOf(Fulfillment.DELIVERY) }
    var name by rememberSaveable { mutableStateOf(user?.name.orEmpty()) }
    var phone by rememberSaveable { mutableStateOf(if (user?.role == "ADMIN") "" else user?.phone.orEmpty()) }
    var address by rememberSaveable { mutableStateOf("") }
    var payment by rememberSaveable { mutableStateOf(Payment.CASH) }
    var nameErr by remember { mutableStateOf<String?>(null) }
    var phoneErr by remember { mutableStateOf<String?>(null) }
    var addrErr by remember { mutableStateOf<String?>(null) }
    val known = vm.draft.mapNotNull { it.price }.sum()
    val unknown = vm.draft.count { it.price == null }

    fun place() {
        nameErr = Validate.name(name)
        phoneErr = Validate.phone(phone)
        addrErr = if (fulfillment == Fulfillment.DELIVERY) Validate.address(address) else null
        if (nameErr == null && phoneErr == null && addrErr == null) {
            vm.placeOrder(fulfillment, name, phone, address, payment, onPlaced)
        }
    }

    Scaffold(
        topBar = { ShopTopBar("Checkout", onBack) },
        bottomBar = {
            if (vm.draft.isNotEmpty()) BottomAction {
                vm.placeError?.let { Text(it, color = Color(0xFFB00020), fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                PrimaryButton(
                    if (vm.placeError != null) "Retry Place Order" else "Place Order",
                    onClick = { place() }, loading = vm.placing, icon = Icons.Filled.Check
                )
            }
        }
    ) { pad ->
        if (vm.draft.isEmpty()) {
            Column(Modifier.padding(pad)) { EmptyState("🛒", "Your list is empty", "Go back and add your groceries.", "Back", onBack) }
        } else {
            Column(
                Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                ShopCard {
                    Text("Your Order", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    vm.draft.forEach { it ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f)) {
                                Text(it.name, fontWeight = FontWeight.SemiBold)
                                Text(if (it.weightUnknown) "Weight: not sure" else it.qtyLabel, fontSize = 13.sp, color = Muted)
                            }
                            Spacer(Modifier.width(8.dp))
                            val p = it.price
                            Text(
                                if (p != null) Money.fmt(p) else "To be confirmed", fontWeight = FontWeight.Bold,
                                color = if (p != null) Color.Unspecified else Warn, textAlign = TextAlign.End,
                                modifier = Modifier.widthIn(max = 120.dp)
                            )
                        }
                    }
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    InfoRow("Subtotal", Money.fmt(known), end = true)
                    InfoRow("Delivery", "FREE", valueColor = GreenOk, end = true, bold = true)
                    InfoRow("Total", Money.total(known, unknown), valueColor = RedPrimary, end = true, bold = true)
                    if (unknown > 0) Text("Some prices are unknown. The shop will confirm the final amount.", fontSize = 12.sp, color = Warn)
                }

                Text("How would you like to receive it?", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                ChoiceCard(fulfillment == Fulfillment.DELIVERY, "Home delivery", "We bring it to your door", { fulfillment = Fulfillment.DELIVERY })
                Row { FreeBadge() }
                ChoiceCard(fulfillment == Fulfillment.PICKUP, "Pickup", "Collect it from the shop", { fulfillment = Fulfillment.PICKUP })

                Text("Your details", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                ShopField(name, { name = it }, "Full name", error = nameErr, capitalization = KeyboardCapitalization.Words)
                ShopField(phone, { phone = it.filter(Char::isDigit).take(10) }, "Phone number", error = phoneErr, keyboardType = KeyboardType.Phone)
                if (fulfillment == Fulfillment.DELIVERY) {
                    ShopField(
                        address, { address = it }, "Delivery address", error = addrErr, singleLine = false, minLines = 3,
                        capitalization = KeyboardCapitalization.Sentences
                    )
                }

                Text("Payment", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                ChoiceCard(payment == Payment.CASH, "Cash", "Pay when you ${if (fulfillment == Fulfillment.DELIVERY) "receive" else "pick up"} your order", { payment = Payment.CASH })
                ChoiceCard(payment == Payment.UPI, "UPI", "Pay by UPI app", { payment = Payment.UPI })
                if (payment == Payment.UPI) {
                    Text(
                        (if (settings.upiId.isNotBlank()) "Pay to UPI ID: ${settings.upiId}. " else "The shop will share UPI details when it confirms your order. ") +
                            "This app does not verify UPI payments — the shop will confirm your payment manually.",
                        fontSize = 13.sp, color = Warn
                    )
                } else {
                    Text("Payment status: pending until you pay the cash.", fontSize = 13.sp, color = Muted)
                }
            }
        }
    }
}

fun paymentLabel(o: com.realsupermarket.app.data.OrderEntity): String {
    val where = if (o.fulfillment == Fulfillment.DELIVERY) "delivery" else "pickup"
    return when {
        o.payment == Payment.CASH && o.paymentConfirmed -> "Cash — received"
        o.payment == Payment.CASH -> "Cash — to be paid on $where"
        o.paymentConfirmed -> "UPI — payment confirmed by shop"
        else -> "UPI — awaiting confirmation by shop"
    }
}

/** The automatic bill. Shows exactly the weights and prices the customer entered. */
@Composable
fun BillCard(o: OrderWithItems, shopName: String) {
    val order = o.order
    ShopCard {
        Text(shopName, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = RedPrimary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Text("Bill", color = Muted, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        HorizontalDivider(Modifier.padding(vertical = 10.dp))
        InfoRow("Order no.", "#${order.orderNo}", bold = true)
        InfoRow("Date", DateFmt.full(order.createdAt))
        InfoRow("Customer", order.customerName)
        InfoRow("Phone", order.phone)
        InfoRow("Method", if (order.fulfillment == Fulfillment.DELIVERY) "Home delivery (FREE)" else "Pickup")
        if (order.fulfillment == Fulfillment.DELIVERY) InfoRow("Address", order.address)
        InfoRow("Payment", paymentLabel(order))
        HorizontalDivider(Modifier.padding(vertical = 10.dp))
        Text("Items", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        o.items.forEach { it ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(it.name, fontWeight = FontWeight.SemiBold)
                    Text(if (it.qtyUnknown) "Weight: not sure" else it.qtyLabel, fontSize = 13.sp, color = Muted)
                }
                Spacer(Modifier.width(8.dp))
                val p = it.price
                Text(
                    if (p != null) Money.fmt(p) else "To be confirmed", fontWeight = FontWeight.Bold,
                    color = if (p != null) Color.Unspecified else Warn, textAlign = TextAlign.End,
                    modifier = Modifier.widthIn(max = 120.dp)
                )
            }
        }
        HorizontalDivider(Modifier.padding(vertical = 10.dp))
        InfoRow(if (order.unknownCount > 0) "Subtotal (known)" else "Subtotal", Money.fmt(order.subtotal), end = true)
        InfoRow("Delivery", if (order.fulfillment == Fulfillment.DELIVERY) "FREE (₹0)" else "Not needed", valueColor = GreenOk, end = true, bold = true)
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(RedLight).padding(12.dp), verticalAlignment = Alignment.Top) {
            Text("Grand Total", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.weight(0.4f))
            Text(Money.total(order.subtotal, order.unknownCount), fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = RedPrimary, textAlign = TextAlign.End, modifier = Modifier.weight(0.6f))
        }
        if (order.unknownCount > 0) {
            Spacer(Modifier.height(6.dp))
            Text("Items marked \"To be confirmed\" are not included in the total. The shop will confirm the final amount.", fontSize = 12.sp, color = Warn)
        }
    }
}

@Composable
fun StatusTimeline(order: com.realsupermarket.app.data.OrderEntity) {
    val status = OrderStatus.from(order.status)
    if (status == OrderStatus.CANCELLED) {
        ShopCard { Text("This order was cancelled.", color = Color(0xFF616161), fontWeight = FontWeight.Bold) }
        return
    }
    val steps = if (order.fulfillment == Fulfillment.DELIVERY)
        listOf(OrderStatus.PLACED, OrderStatus.CONFIRMED, OrderStatus.PREPARING, OrderStatus.OUT_FOR_DELIVERY, OrderStatus.DELIVERED)
    else listOf(OrderStatus.PLACED, OrderStatus.CONFIRMED, OrderStatus.PREPARING, OrderStatus.READY, OrderStatus.DELIVERED)
    ShopCard {
        Text("Order status", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text("Current status: ${status.label}", color = RedPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.height(8.dp))
        steps.forEachIndexed { i, s ->
            val done = s.ordinal <= status.ordinal
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(22.dp).clip(CircleShape).background(if (done) RedPrimary else Color(0xFFDDDDDD)), contentAlignment = Alignment.Center) {
                    if (done) Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                }
                Spacer(Modifier.width(12.dp))
                Text(s.label, fontWeight = if (s == status) FontWeight.Bold else FontWeight.Normal, color = if (done) Color.Unspecified else Muted)
            }
            if (i < steps.lastIndex) {
                Box(Modifier.padding(start = 10.dp).width(2.dp).height(14.dp).background(if (steps[i + 1].ordinal <= status.ordinal) RedPrimary else Color(0xFFDDDDDD)))
            }
        }
    }
}

@Composable
fun OrderDetailScreen(vm: AppViewModel, orderId: Long, placed: Boolean, onBack: () -> Unit) {
    val poller = remember(orderId) { vm.repo.orderPoller(orderId) }
    val state by poller.state.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    Scaffold(
        topBar = {
            ShopTopBar(if (placed) "Order Placed" else "Order Details", onBack) {
                TextButton(onClick = { poller.refresh() }) { Text("Refresh", color = Color.White, fontWeight = FontWeight.Bold) }
            }
        },
        bottomBar = { if (placed) BottomAction { PrimaryButton("Back to Home", onClick = onBack) } }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            LoadGate(state, onRetry = { poller.refresh() }) { l ->
                when (l) {
                    is OrderLookup.Missing -> EmptyState("🔍", "Order not found", "We couldn't find this order.", "Back", onBack)
                    is OrderLookup.Found -> Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        if (placed) {
                            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = GreenOk, modifier = Modifier.size(64.dp))
                                Text("Order Placed Successfully!", color = GreenOk, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                                Text("Saved to the shop's server. Thank you for shopping with us!", color = Muted, textAlign = TextAlign.Center)
                            }
                        }
                        StatusTimeline(l.order.order)
                        val boy = l.order.order
                        if (boy.deliveryBoyName.isNotBlank() && boy.status == OrderStatus.OUT_FOR_DELIVERY.name) {
                            ShopCard {
                                Text("🛵 On the way", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = RedPrimary)
                                Text("${boy.deliveryBoyName} is delivering your order.", modifier = Modifier.padding(top = 4.dp))
                                if (boy.deliveryBoyPhone.isNotBlank()) Text("Phone: ${boy.deliveryBoyPhone}", color = Muted)
                            }
                        }
                        BillCard(l.order, settings.shopName)
                    }
                }
            }
        }
    }
}
