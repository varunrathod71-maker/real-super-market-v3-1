package com.realsupermarket.app

import android.app.Application
import com.realsupermarket.app.data.ShopRepository
import com.realsupermarket.app.net.SessionStore
import com.realsupermarket.app.net.SupabaseApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Application object: builds the Supabase client and repository once. */
class ShopApp : Application() {
    lateinit var repo: ShopRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val session = SessionStore(this)
        repo = ShopRepository(SupabaseApi(session), session, CoroutineScope(SupervisorJob() + Dispatchers.Default))
    }
}
