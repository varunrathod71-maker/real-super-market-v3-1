package com.realsupermarket.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.realsupermarket.app.data.UserEntity
import com.realsupermarket.app.logic.Validate
import com.realsupermarket.app.ui.AppViewModel
import com.realsupermarket.app.ui.components.PrimaryButton
import com.realsupermarket.app.ui.components.ShopField
import com.realsupermarket.app.ui.theme.RedPrimary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(route: String?, onDone: (String) -> Unit) {
    LaunchedEffect(route) {
        if (route != null) {
            delay(1100)
            onDone(route)
        }
    }
    Column(
        Modifier.fillMaxSize().background(RedPrimary),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.ShoppingCart, contentDescription = null, tint = Color.White, modifier = Modifier.size(96.dp))
        Spacer(Modifier.height(16.dp))
        Text("Real Supermarket", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
        Text("Shop Smart. Live Better.", color = Color.White.copy(alpha = 0.9f), fontSize = 16.sp)
        Spacer(Modifier.height(28.dp))
        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
    }
}

@Composable
fun LoginScreen(vm: AppViewModel, onLoggedIn: (UserEntity) -> Unit) {
    var signUp by rememberSaveable { mutableStateOf(false) }
    var name by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var showPw by remember { mutableStateOf(false) }
    var nameErr by remember { mutableStateOf<String?>(null) }
    var phoneErr by remember { mutableStateOf<String?>(null) }
    var pwErr by remember { mutableStateOf<String?>(null) }
    var formErr by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun submit() {
        nameErr = if (signUp) Validate.name(name) else null
        phoneErr = if (signUp) Validate.phone(phone) else if (phone.isBlank()) "Enter your mobile number" else null
        pwErr = if (signUp) Validate.password(password) else if (password.isEmpty()) "Enter your password" else null
        formErr = null
        if (nameErr != null || phoneErr != null || pwErr != null) return
        loading = true
        scope.launch {
            try {
                val u = if (signUp) vm.repo.register(name.trim(), phone.trim(), password) else vm.repo.login(phone.trim(), password)
                onLoggedIn(u)
            } catch (e: IllegalArgumentException) {
                formErr = e.message
            } catch (e: Exception) {
                formErr = e.message ?: "Something went wrong. Please try again."
            } finally {
                loading = false
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
                .background(RedPrimary).padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Filled.ShoppingCart, contentDescription = null, tint = Color.White, modifier = Modifier.size(64.dp))
            Spacer(Modifier.height(8.dp))
            Text(if (signUp) "Create Account" else "Welcome Back!", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text(if (signUp) "Sign up to start ordering" else "Sign in to continue", color = Color.White.copy(alpha = 0.9f), fontSize = 15.sp)
        }
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Spacer(Modifier.height(8.dp))
            if (signUp) {
                ShopField(
                    name, { name = it }, "Full name", error = nameErr,
                    capitalization = KeyboardCapitalization.Words
                )
            }
            ShopField(
                phone, { phone = if (signUp) it.filter(Char::isDigit).take(10) else it.take(60) },
                if (signUp) "Mobile number" else "Mobile number or email",
                error = phoneErr, keyboardType = if (signUp) KeyboardType.Phone else KeyboardType.Text
            )
            ShopField(
                password, { password = it }, "Password", error = pwErr, password = !showPw,
                keyboardType = KeyboardType.Password, imeAction = ImeAction.Done,
                trailing = { TextButton(onClick = { showPw = !showPw }) { Text(if (showPw) "Hide" else "Show", color = RedPrimary) } }
            )
            formErr?.let {
                Text(it, color = MaterialColors.error, fontSize = 14.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(4.dp))
            PrimaryButton(if (signUp) "Create Account" else "Login", onClick = { submit() }, loading = loading)
            TextButton(
                onClick = { signUp = !signUp; nameErr = null; phoneErr = null; pwErr = null; formErr = null },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    if (signUp) "Already have an account? Log in" else "Don't have an account? Sign up",
                    color = RedPrimary, fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

private object MaterialColors { val error = Color(0xFFB00020) }

/** Shown when the APK was built without the Supabase secrets. */
@Composable
fun NotConfiguredScreen() {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text("⚙️", fontSize = 52.sp)
        Spacer(Modifier.height(12.dp))
        Text("Backend not connected", fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(
            "This APK was built without SUPABASE_URL and SUPABASE_ANON_KEY, so it cannot share orders between phones. " +
                "Add both as GitHub repository secrets and rebuild.",
            textAlign = TextAlign.Center
        )
    }
}
