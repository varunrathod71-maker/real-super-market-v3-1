package com.realsupermarket.app.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.withTimeoutOrNull

/** What a screen shows while data comes from the cloud. */
sealed interface Load<out T> {
    data object Loading : Load<Nothing>
    /** [warning] is set when the last refresh failed (offline) and old data is still being shown. */
    data class Ok<T>(val data: T, val warning: String? = null) : Load<T>
    data class Failed(val message: String) : Load<Nothing>
}

/**
 * Reads from the cloud again and again (every [intervalMs]) while a screen is watching it,
 * so new orders / status changes from other phones show up automatically.
 * [refresh] reloads immediately (Retry button, after saving something).
 */
class Poller<T>(scope: CoroutineScope, private val intervalMs: Long = 6000L, private val fetch: suspend () -> T) {
    private val kick = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

    val state: StateFlow<Load<T>> = flow<Load<T>> {
        var last: T? = null
        while (true) {
            if (last == null) emit(Load.Loading)
            try {
                val data = fetch()
                last = data
                emit(Load.Ok(data))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val old = last
                emit(
                    if (old != null) Load.Ok(old, e.message ?: "Can't refresh right now.")
                    else Load.Failed(e.message ?: "Something went wrong.")
                )
            }
            withTimeoutOrNull(intervalMs) { kick.first() }
        }
    }.stateIn(scope, SharingStarted.WhileSubscribed(3000, 0), Load.Loading)

    fun refresh() {
        kick.tryEmit(Unit)
    }
}
