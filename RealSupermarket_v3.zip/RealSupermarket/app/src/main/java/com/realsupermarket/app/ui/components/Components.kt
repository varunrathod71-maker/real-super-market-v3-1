@file:OptIn(ExperimentalMaterial3Api::class)

package com.realsupermarket.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.realsupermarket.app.data.Fulfillment
import com.realsupermarket.app.data.Load
import com.realsupermarket.app.data.OrderStatus
import com.realsupermarket.app.data.OrderWithItems
import com.realsupermarket.app.logic.DateFmt
import com.realsupermarket.app.logic.Money
import com.realsupermarket.app.ui.theme.GreenBg
import com.realsupermarket.app.ui.theme.GreenOk
import com.realsupermarket.app.ui.theme.Muted
import com.realsupermarket.app.ui.theme.RedDark
import com.realsupermarket.app.ui.theme.RedLight
import com.realsupermarket.app.ui.theme.RedPrimary
import kotlinx.coroutines.CancellationException

@Composable
fun ShopTopBar(title: String, onBack: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    TopAppBar(
        title = { Text(title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        navigationIcon = {
            if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
        },
        actions = actions,
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = RedPrimary, titleContentColor = Color.White,
            navigationIconContentColor = Color.White, actionIconContentColor = Color.White
        )
    )
}

@Composable
fun PrimaryButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier,
    enabled: Boolean = true, loading: Boolean = false, icon: ImageVector? = null
) {
    Button(
        onClick = onClick, enabled = enabled && !loading,
        modifier = modifier.fillMaxWidth().heightIn(min = 56.dp),
        shape = RoundedCornerShape(28.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = RedPrimary, contentColor = Color.White,
            disabledContainerColor = Color(0xFFE0B4B4), disabledContentColor = Color.White
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
    ) {
        if (loading) {
            CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
        } else {
            if (icon != null) { Icon(icon, contentDescription = null); Spacer(Modifier.width(8.dp)) }
            Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun SecondaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    OutlinedButton(
        onClick = onClick, modifier = modifier.fillMaxWidth().heightIn(min = 52.dp),
        shape = RoundedCornerShape(26.dp), border = BorderStroke(1.5.dp, RedPrimary),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = RedPrimary)
    ) { Text(text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun ShopCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) { Column(Modifier.padding(16.dp), content = content) }
}

/** Sticky bar at the bottom of a screen holding the main action; never overlaps scrolling content. */
@Composable
fun BottomAction(content: @Composable ColumnScope.() -> Unit) {
    Surface(shadowElevation = 10.dp, color = Color.White) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
fun ShopField(
    value: String, onValueChange: (String) -> Unit, label: String, modifier: Modifier = Modifier,
    error: String? = null, keyboardType: KeyboardType = KeyboardType.Text, enabled: Boolean = true,
    singleLine: Boolean = true, minLines: Int = 1, prefix: String? = null, password: Boolean = false,
    capitalization: KeyboardCapitalization = KeyboardCapitalization.None, imeAction: ImeAction = ImeAction.Next,
    trailing: (@Composable () -> Unit)? = null
) {
    OutlinedTextField(
        value = value, onValueChange = onValueChange, label = { Text(label) },
        modifier = modifier.fillMaxWidth(), enabled = enabled, isError = error != null,
        supportingText = error?.let { { Text(it) } },
        singleLine = singleLine, minLines = minLines,
        prefix = prefix?.let { { Text(it) } },
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, capitalization = capitalization, imeAction = imeAction),
        trailingIcon = trailing, shape = RoundedCornerShape(14.dp), colors = shopFieldColors()
    )
}

@Composable
fun shopFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = RedPrimary, focusedLabelColor = RedPrimary, cursorColor = RedPrimary
)

@Composable
fun chipColors() = FilterChipDefaults.filterChipColors(selectedContainerColor = RedPrimary, selectedLabelColor = Color.White)

@Composable
fun LabeledCheck(checked: Boolean, onChange: (Boolean) -> Unit, text: String) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = null, colors = CheckboxDefaults.colors(checkedColor = RedPrimary))
        Spacer(Modifier.width(10.dp))
        Text(text, fontSize = 15.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
fun StatusChip(status: OrderStatus) {
    val (bg, fg) = when (status) {
        OrderStatus.DELIVERED -> GreenBg to GreenOk
        OrderStatus.CANCELLED -> Color(0xFFEEEEEE) to Color(0xFF616161)
        else -> RedLight to RedDark
    }
    Text(
        status.label, color = fg, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(bg).padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
fun FreeBadge(modifier: Modifier = Modifier) {
    Text(
        "✔ FREE DELIVERY", color = GreenOk, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold,
        modifier = modifier.clip(RoundedCornerShape(50)).background(GreenBg).padding(horizontal = 12.dp, vertical = 5.dp)
    )
}

@Composable
fun LoadingBox() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = RedPrimary)
            Spacer(Modifier.height(12.dp))
            Text("Loading…", color = Muted)
        }
    }
}

@Composable
fun EmptyState(emoji: String, title: String, message: String, actionText: String? = null, onAction: (() -> Unit)? = null) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text(emoji, fontSize = 52.sp)
        Spacer(Modifier.height(12.dp))
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(message, color = Muted, textAlign = TextAlign.Center)
        if (actionText != null && onAction != null) {
            Spacer(Modifier.height(20.dp))
            PrimaryButton(actionText, onAction, Modifier.widthIn(max = 280.dp))
        }
    }
}

@Composable
fun ErrorState(message: String, onRetry: () -> Unit) =
    EmptyState("⚠️", "Something went wrong", message, "Retry", onRetry)

@Composable
fun InfoRow(label: String, value: String, valueColor: Color = Color.Unspecified, end: Boolean = false, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
        Text(label, color = Muted, fontSize = 14.sp, modifier = Modifier.width(96.dp))
        Text(
            value, color = valueColor, fontSize = 14.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium,
            textAlign = if (end) TextAlign.End else TextAlign.Start, modifier = Modifier.weight(1f)
        )
    }
}

fun itemsSummary(o: OrderWithItems): String {
    val names = o.items.map { it.name }
    return if (names.size <= 3) names.joinToString(", ") else names.take(3).joinToString(", ") + " +${names.size - 3} more"
}

@Composable
fun OrderCard(o: OrderWithItems, showCustomer: Boolean = false, onClick: () -> Unit) {
    Card(
        onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text("#${o.order.orderNo}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(DateFmt.full(o.order.createdAt), fontSize = 12.sp, color = Muted)
                if (showCustomer) Text("${o.order.customerName} • ${o.order.phone}", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(6.dp))
                Text(itemsSummary(o), fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(6.dp))
                Text(
                    if (o.order.fulfillment == Fulfillment.DELIVERY) "Home delivery • FREE" else "Pickup",
                    fontSize = 12.sp, color = Muted
                )
                if (showCustomer && o.order.fulfillment == Fulfillment.DELIVERY) {
                    Text(
                        if (o.order.deliveryBoyName.isBlank()) "🛵 Not assigned" else "🛵 ${o.order.deliveryBoyName}",
                        fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                        color = if (o.order.deliveryBoyName.isBlank()) Color(0xFFD84315) else GreenOk
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(horizontalAlignment = Alignment.End, modifier = Modifier.widthIn(max = 130.dp)) {
                Text(
                    Money.total(o.order.subtotal, o.order.unknownCount), fontWeight = FontWeight.Bold,
                    fontSize = 15.sp, color = RedPrimary, textAlign = TextAlign.End
                )
                Spacer(Modifier.height(8.dp))
                StatusChip(OrderStatus.from(o.order.status))
            }
        }
    }
}

/** Runs [block]; shows the error message in a snackbar instead of crashing. */
suspend fun SnackbarHostState.guard(okMessage: String? = null, block: suspend () -> Unit) {
    try {
        block()
        if (okMessage != null) showSnackbar(okMessage)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        showSnackbar(e.message ?: "Something went wrong. Please try again.")
    }
}

/** Shows loading / error+Retry / data. If a refresh fails after data was shown, keeps the data and shows an offline banner. */
@Composable
fun <T> LoadGate(state: Load<T>, onRetry: () -> Unit, content: @Composable (T) -> Unit) {
    when (state) {
        is Load.Loading -> LoadingBox()
        is Load.Failed -> ErrorState(state.message, onRetry)
        is Load.Ok -> Column(Modifier.fillMaxSize()) {
            if (state.warning != null) OfflineBanner(state.warning, onRetry)
            Box(Modifier.weight(1f)) { content(state.data) }
        }
    }
}

@Composable
fun OfflineBanner(message: String, onRetry: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(RedLight).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Can't reach the shop server - showing the last loaded data. $message", color = RedDark, fontSize = 12.sp, modifier = Modifier.weight(1f))
        TextButton(onClick = onRetry) { Text("Retry", color = RedPrimary, fontWeight = FontWeight.Bold) }
    }
}
