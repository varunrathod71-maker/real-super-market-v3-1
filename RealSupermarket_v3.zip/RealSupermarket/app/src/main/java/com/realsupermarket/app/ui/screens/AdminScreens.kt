@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.realsupermarket.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.realsupermarket.app.data.Fulfillment
import com.realsupermarket.app.data.Load
import com.realsupermarket.app.data.OrderLookup
import com.realsupermarket.app.data.OrderStatus
import com.realsupermarket.app.data.OrderWithItems
import com.realsupermarket.app.data.Payment
import com.realsupermarket.app.data.ProductEntity
import com.realsupermarket.app.data.Role
import com.realsupermarket.app.data.ShopSettings
import com.realsupermarket.app.data.UserEntity
import com.realsupermarket.app.logic.DateFmt
import com.realsupermarket.app.logic.Money
import com.realsupermarket.app.logic.fmtNum
import com.realsupermarket.app.ui.AppViewModel
import com.realsupermarket.app.ui.components.EmptyState
import com.realsupermarket.app.ui.components.InfoRow
import com.realsupermarket.app.ui.components.LabeledCheck
import com.realsupermarket.app.ui.components.LoadGate
import com.realsupermarket.app.ui.components.OrderCard
import com.realsupermarket.app.ui.components.PrimaryButton
import com.realsupermarket.app.ui.components.SecondaryButton
import com.realsupermarket.app.ui.components.ShopCard
import com.realsupermarket.app.ui.components.ShopField
import com.realsupermarket.app.ui.components.ShopTopBar
import com.realsupermarket.app.ui.components.StatusChip
import com.realsupermarket.app.ui.components.chipColors
import com.realsupermarket.app.ui.components.guard
import com.realsupermarket.app.ui.theme.GreenOk
import com.realsupermarket.app.ui.theme.Muted
import com.realsupermarket.app.ui.theme.RedLight
import com.realsupermarket.app.ui.theme.RedPrimary
import com.realsupermarket.app.ui.theme.Warn
import kotlinx.coroutines.launch
import java.util.Calendar

@Composable
fun AdminMain(vm: AppViewModel, onOpenOrder: (Long) -> Unit, onLogout: () -> Unit) {
    val user by vm.currentUser.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val snack = remember { SnackbarHostState() }
    val tabs = listOf("Dashboard", "Orders", "Products", "Customers", "Delivery", "Transactions", "Settings")
    Scaffold(
        topBar = {
            ShopTopBar("Admin Dashboard") {
                TextButton(onClick = { vm.repo.allOrders.refresh(); vm.repo.allProducts.refresh(); vm.repo.customers.refresh(); vm.repo.deliveryBoys.refresh() }) {
                    Text("Refresh", color = Color.White, fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = onLogout) { Text("Logout", color = Color.White, fontWeight = FontWeight.Bold) }
            }
        },
        snackbarHost = { SnackbarHost(snack) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (user != null && user?.role != Role.ADMIN) {
                EmptyState("🔒", "Admin access only", "This area is only for the shop admin.", "Log out", onLogout)
            } else {
                ScrollableTabRow(selectedTabIndex = tab, containerColor = Color.White, contentColor = RedPrimary, edgePadding = 8.dp) {
                    tabs.forEachIndexed { i, t ->
                        Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, fontWeight = FontWeight.SemiBold) })
                    }
                }
                Box(Modifier.weight(1f)) {
                    when (tab) {
                        0 -> DashboardTab(vm, onOpenOrder)
                        1 -> AdminOrdersTab(vm, onOpenOrder)
                        2 -> ProductsTab(vm, snack)
                        3 -> CustomersTab(vm)
                        4 -> DeliveryBoysTab(vm, snack)
                        5 -> TransactionsTab(vm, onOpenOrder)
                        else -> SettingsTab(vm, snack)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatTile(title: String, value: String, modifier: Modifier) {
    Card(
        modifier = modifier, shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = RedPrimary)
        }
    }
}

@Composable
private fun DashboardTab(vm: AppViewModel, onOpenOrder: (Long) -> Unit) {
    val oState by vm.repo.allOrders.state.collectAsStateWithLifecycle()
    val cState by vm.repo.customers.state.collectAsStateWithLifecycle()
    val customerCount = when (val c = cState) { is Load.Ok -> c.data.size; else -> 0 }
    LoadGate(oState, { vm.repo.allOrders.refresh() }) { all -> DashboardContent(all, customerCount, onOpenOrder) }
}

@Composable
private fun DashboardContent(all: List<OrderWithItems>, customerCount: Int, onOpenOrder: (Long) -> Unit) {
    val valid = all.filter { it.order.status != OrderStatus.CANCELLED.name }
    val sales = valid.sumOf { it.order.subtotal }
    val pending = all.count { it.order.status == OrderStatus.PLACED.name || it.order.status == OrderStatus.CONFIRMING.name }
    // last 7 days of sales for the chart
    val dayStarts = (6 downTo 0).map { off ->
        Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -off)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
    val totals = dayStarts.map { s -> valid.filter { it.order.createdAt >= s && it.order.createdAt < s + 86_400_000L }.sumOf { it.order.subtotal } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Total orders", "${all.size}", Modifier.weight(1f))
            StatTile("Total sales", Money.fmt(sales), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Customers", "$customerCount", Modifier.weight(1f))
            StatTile("New / confirming", "$pending", Modifier.weight(1f))
        }
        ShopCard {
            Text("Sales — last 7 days", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(10.dp))
            val maxV = (totals.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
            Canvas(Modifier.fillMaxWidth().height(120.dp)) {
                val slot = size.width / totals.size
                val bw = slot * 0.5f
                totals.forEachIndexed { i, v ->
                    val h = ((v / maxV).toFloat() * size.height).coerceAtLeast(4f)
                    drawRoundRect(RedPrimary, Offset(i * slot + (slot - bw) / 2f, size.height - h), Size(bw, h), CornerRadius(8f, 8f))
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                dayStarts.forEach { Text(DateFmt.weekday(it), fontSize = 11.sp, color = Muted, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)) }
            }
        }
        Text("Recent orders", fontSize = 17.sp, fontWeight = FontWeight.Bold)
        if (all.isEmpty()) Text("No orders yet.", color = Muted)
        all.take(5).forEach { o -> OrderCard(o, showCustomer = true) { onOpenOrder(o.order.id) } }
    }
}

@Composable
private fun AdminOrdersTab(vm: AppViewModel, onOpenOrder: (Long) -> Unit) {
    val state by vm.repo.allOrders.state.collectAsStateWithLifecycle()
    LoadGate(state, { vm.repo.allOrders.refresh() }) { all -> AdminOrdersContent(all, onOpenOrder) }
}

@Composable
private fun AdminOrdersContent(all: List<OrderWithItems>, onOpenOrder: (Long) -> Unit) {
    var filter by rememberSaveable { mutableStateOf("ALL") }
    val shown = if (filter == "ALL") all else all.filter { it.order.status == filter }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = filter == "ALL", onClick = { filter = "ALL" }, label = { Text("All") }, colors = chipColors())
            OrderStatus.entries.forEach { s ->
                FilterChip(selected = filter == s.name, onClick = { filter = s.name }, label = { Text(s.label) }, colors = chipColors())
            }
        }
        if (shown.isEmpty()) {
            EmptyState("📦", "No orders", "Customer orders will appear here.")
        } else {
            LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(shown, key = { it.order.id }) { o -> OrderCard(o, showCustomer = true) { onOpenOrder(o.order.id) } }
            }
        }
    }
}

/** Order details for the admin: full customer data, bill, status and payment controls. */
@Composable
fun AdminOrderScreen(vm: AppViewModel, orderId: Long, onBack: () -> Unit) {
    val poller = remember(orderId) { vm.repo.orderPoller(orderId) }
    val state by poller.state.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    Scaffold(
        topBar = {
            ShopTopBar("Order Details", onBack) {
                TextButton(onClick = { poller.refresh() }) { Text("Refresh", color = Color.White, fontWeight = FontWeight.Bold) }
            }
        },
        snackbarHost = { SnackbarHost(snack) }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            LoadGate(state, onRetry = { poller.refresh() }) { l ->
                when (l) {
                    is OrderLookup.Missing -> EmptyState("🔒", "Not available", "This order can't be shown.", "Back", onBack)
                    is OrderLookup.Found -> {
                        val o = l.order.order
                        val current = OrderStatus.from(o.status)
                        val options = OrderStatus.entries.filter {
                            if (o.fulfillment == Fulfillment.DELIVERY) it != OrderStatus.READY else it != OrderStatus.OUT_FOR_DELIVERY
                        }
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            ShopCard {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                    Text("Update status", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                                    StatusChip(current)
                                }
                                Spacer(Modifier.height(8.dp))
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    options.forEach { st ->
                                        FilterChip(
                                            selected = st == current, label = { Text(st.label) }, colors = chipColors(),
                                            onClick = {
                                                scope.launch {
                                                    snack.guard("Status saved: ${st.label}") { vm.repo.updateStatus(o.id, st); poller.refresh() }
                                                }
                                            }
                                        )
                                    }
                                }
                            }
                            if (o.fulfillment == Fulfillment.DELIVERY) AssignDeliveryCard(vm, o.id, o.deliveryBoyId, o.deliveryBoyName, o.deliveryBoyPhone, snack) { poller.refresh() }
                            ShopCard {
                                Text("Payment", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text(paymentLabel(o), modifier = Modifier.padding(vertical = 6.dp))
                                if (o.payment == Payment.UPI) Text("UPI is not verified by the app. Confirm in your UPI app, then mark as received.", fontSize = 12.sp, color = Warn)
                                Spacer(Modifier.height(8.dp))
                                SecondaryButton(
                                    if (o.paymentConfirmed) "Mark payment as NOT received" else "Mark payment as received",
                                    onClick = { scope.launch { snack.guard("Payment updated") { vm.repo.setPaymentConfirmed(o.id, !o.paymentConfirmed); poller.refresh() } } }
                                )
                            }
                            BillCard(l.order, settings.shopName)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductsTab(vm: AppViewModel, snack: SnackbarHostState) {
    val state by vm.repo.allProducts.state.collectAsStateWithLifecycle()
    LoadGate(state, { vm.repo.allProducts.refresh() }) { list -> ProductsContent(vm, snack, list) }
}

@Composable
private fun ProductsContent(vm: AppViewModel, snack: SnackbarHostState, list: List<ProductEntity>) {
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf<ProductEntity?>(null) }
    var adding by remember { mutableStateOf(false) }
    var stockFor by remember { mutableStateOf<ProductEntity?>(null) }
    var deleting by remember { mutableStateOf<ProductEntity?>(null) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PrimaryButton("Add Product", onClick = { adding = true }) }
        if (list.isEmpty()) item { Text("No products yet. Tap Add Product.", color = Muted) }
        items(list, key = { it.id }) { p ->
            ShopCard {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(p.emoji, fontSize = 30.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("${Money.fmt(p.price)}/${p.unit} • ${p.category}", fontSize = 13.sp, color = Muted)
                        Text(
                            "Stock: ${fmtNum(p.stock)} ${p.unit}" + if (p.loose) " • loose" else "",
                            fontSize = 13.sp, color = if (p.stock <= 0) Warn else GreenOk, fontWeight = FontWeight.SemiBold
                        )
                    }
                    Switch(
                        checked = p.active,
                        onCheckedChange = { v -> scope.launch { snack.guard { vm.repo.saveProduct(p.copy(active = v)) } } },
                        colors = SwitchDefaults.colors(checkedTrackColor = RedPrimary)
                    )
                }
                Text(if (p.active) "Active — visible to customers" else "Inactive — hidden", fontSize = 12.sp, color = Muted)
                Row {
                    TextButton(onClick = { editing = p }) { Text("Edit", color = RedPrimary, fontWeight = FontWeight.Bold) }
                    TextButton(onClick = { stockFor = p }) { Text("Stock", color = RedPrimary, fontWeight = FontWeight.Bold) }
                    TextButton(onClick = { deleting = p }) { Text("Delete", color = Color(0xFF616161)) }
                }
            }
        }
    }
    if (adding) ProductDialog(null, { adding = false }) { p -> adding = false; scope.launch { snack.guard("Product added") { vm.repo.saveProduct(p) } } }
    editing?.let { cur -> ProductDialog(cur, { editing = null }) { p -> editing = null; scope.launch { snack.guard("Product saved") { vm.repo.saveProduct(p) } } } }
    stockFor?.let { cur ->
        var txt by remember(cur.id) { mutableStateOf(fmtNum(cur.stock)) }
        val v = txt.trim().toDoubleOrNull()
        AlertDialog(
            onDismissRequest = { stockFor = null }, containerColor = Color.White,
            title = { Text("Stock — ${cur.name}", fontWeight = FontWeight.Bold) },
            text = { ShopField(txt, { txt = it }, "Stock (${cur.unit})", error = if (v == null || v < 0) "Enter 0 or more" else null, keyboardType = KeyboardType.Decimal) },
            confirmButton = {
                TextButton(onClick = {
                    if (v != null && v >= 0) { stockFor = null; scope.launch { snack.guard("Stock updated") { vm.repo.saveProduct(cur.copy(stock = v)) } } }
                }) { Text("Save", color = RedPrimary, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { stockFor = null }) { Text("Cancel", color = Muted) } }
        )
    }
    deleting?.let { cur ->
        AlertDialog(
            onDismissRequest = { deleting = null }, containerColor = Color.White,
            title = { Text("Delete ${cur.name}?", fontWeight = FontWeight.Bold) },
            text = { Text("Old orders keep their item names and prices. Use the switch to hide a product instead of deleting.") },
            confirmButton = {
                TextButton(onClick = { deleting = null; scope.launch { snack.guard("Deleted") { vm.repo.deleteProduct(cur.id) } } }) { Text("Delete", color = RedPrimary, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel", color = Muted) } }
        )
    }
}

@Composable
private fun ProductDialog(existing: ProductEntity?, onDismiss: () -> Unit, onSave: (ProductEntity) -> Unit) {
    var name by remember { mutableStateOf(existing?.name.orEmpty()) }
    var desc by remember { mutableStateOf(existing?.description.orEmpty()) }
    var category by remember { mutableStateOf(existing?.category.orEmpty()) }
    var price by remember { mutableStateOf(existing?.price?.let { fmtNum(it) }.orEmpty()) }
    var stock by remember { mutableStateOf(existing?.stock?.let { fmtNum(it) } ?: "0") }
    var unit by remember { mutableStateOf(existing?.unit ?: "kg") }
    var emoji by remember { mutableStateOf(existing?.emoji ?: "🛒") }
    var loose by remember { mutableStateOf(existing?.loose ?: false) }
    var active by remember { mutableStateOf(existing?.active ?: true) }
    var show by remember { mutableStateOf(false) }
    val nameErr = if (name.isBlank()) "Enter the product name" else null
    val pv = price.trim().toDoubleOrNull()
    val priceErr = if (pv == null || pv <= 0.0) "Enter a valid price" else null
    val sv = stock.trim().toDoubleOrNull()
    val stockErr = if (sv == null || sv < 0.0) "Enter stock (0 or more)" else null
    val unitErr = if (unit.isBlank()) "Enter a unit, e.g. kg" else null
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Color.White,
        title = { Text(if (existing == null) "Add Product" else "Edit Product", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ShopField(name, { name = it }, "Product name", error = if (show) nameErr else null, capitalization = KeyboardCapitalization.Words)
                ShopField(desc, { desc = it }, "Description")
                ShopField(category, { category = it }, "Category")
                ShopField(price, { price = it }, "Price per unit", prefix = "₹", keyboardType = KeyboardType.Decimal, error = if (show) priceErr else null)
                ShopField(stock, { stock = it }, "Stock", keyboardType = KeyboardType.Decimal, error = if (show) stockErr else null)
                ShopField(unit, { unit = it }, "Unit (kg, g, litre, packet…)", error = if (show) unitErr else null)
                ShopField(emoji, { emoji = it.take(4) }, "Emoji / icon")
                LabeledCheck(loose, { loose = it }, "Sold loose by weight (rice, dal, pulses)")
                LabeledCheck(active, { active = it }, "Active (visible to customers)")
            }
        },
        confirmButton = {
            TextButton(onClick = {
                show = true
                if (listOf(nameErr, priceErr, stockErr, unitErr).all { it == null }) {
                    onSave(
                        ProductEntity(
                            id = existing?.id ?: 0, name = name.trim(), description = desc.trim(), category = category.trim(),
                            price = pv!!, stock = sv!!, unit = unit.trim(), emoji = emoji.ifBlank { "🛒" }, active = active, loose = loose
                        )
                    )
                }
            }) { Text("Save", color = RedPrimary, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Muted) } }
    )
}

@Composable
private fun CustomersTab(vm: AppViewModel) {
    val cState by vm.repo.customers.state.collectAsStateWithLifecycle()
    val oState by vm.repo.allOrders.state.collectAsStateWithLifecycle()
    val orders = when (val o = oState) { is Load.Ok -> o.data; else -> emptyList() }
    LoadGate(cState, { vm.repo.customers.refresh() }) { list -> CustomersContent(list, orders) }
}

@Composable
private fun CustomersContent(list: List<UserEntity>, orders: List<OrderWithItems>) {
    if (list.isEmpty()) { EmptyState("👥", "No customers yet", "Customers appear here after they sign up."); return }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(list, key = { it.id }) { c ->
            val mine = orders.filter { it.order.userId == c.id }
            ShopCard {
                Text(c.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(c.phone, color = Muted)
                Text("Joined ${DateFmt.full(c.createdAt)}", fontSize = 12.sp, color = Muted)
                Text("${mine.size} order${if (mine.size == 1) "" else "s"} • ${Money.fmt(mine.filter { it.order.status != OrderStatus.CANCELLED.name }.sumOf { it.order.subtotal })} known spend", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun TransactionsTab(vm: AppViewModel, onOpenOrder: (Long) -> Unit) {
    val state by vm.repo.allOrders.state.collectAsStateWithLifecycle()
    LoadGate(state, { vm.repo.allOrders.refresh() }) { all -> TransactionsContent(all, onOpenOrder) }
}

@Composable
private fun TransactionsContent(all: List<OrderWithItems>, onOpenOrder: (Long) -> Unit) {
    if (all.isEmpty()) { EmptyState("💳", "No transactions", "Payments for orders will be listed here."); return }
    val live = all.filter { it.order.status != OrderStatus.CANCELLED.name }
    val received = live.filter { it.order.paymentConfirmed }.sumOf { it.order.subtotal }
    val pending = live.filter { !it.order.paymentConfirmed }.sumOf { it.order.subtotal }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile("Received", Money.fmt(received), Modifier.weight(1f))
                StatTile("Pending", Money.fmt(pending), Modifier.weight(1f))
            }
        }
        items(all, key = { it.order.id }) { o ->
            Card(
                onClick = { onOpenOrder(o.order.id) }, modifier = Modifier.fillMaxWidth(),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = androidx.compose.ui.Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text("#${o.order.orderNo} • ${o.order.customerName}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(DateFmt.full(o.order.createdAt), fontSize = 12.sp, color = Muted)
                        Text(paymentLabel(o.order), fontSize = 12.sp, color = if (o.order.paymentConfirmed) GreenOk else Warn)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(Money.total(o.order.subtotal, o.order.unknownCount), fontWeight = FontWeight.Bold, color = RedPrimary, fontSize = 14.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.6f))
                }
            }
        }
    }
}

@Composable
private fun SettingsTab(vm: AppViewModel, snack: SnackbarHostState) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var shopName by remember(settings) { mutableStateOf(settings.shopName) }
    var phone by remember(settings) { mutableStateOf(settings.phone) }
    var address by remember(settings) { mutableStateOf(settings.address) }
    var upi by remember(settings) { mutableStateOf(settings.upiId) }
    var oldPw by remember { mutableStateOf("") }
    var newPw by remember { mutableStateOf("") }
    var nameErr by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ShopCard {
            Text("Supermarket settings", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ShopField(shopName, { shopName = it }, "Supermarket name", error = nameErr)
                ShopField(phone, { phone = it }, "Shop phone", keyboardType = KeyboardType.Phone)
                ShopField(address, { address = it }, "Shop address", singleLine = false, minLines = 2)
                ShopField(upi, { upi = it }, "UPI ID (shown to customers who choose UPI)")
                PrimaryButton("Save settings", onClick = {
                    nameErr = if (shopName.isBlank()) "Enter the supermarket name" else null
                    if (nameErr == null) scope.launch { snack.guard("Settings saved") { vm.repo.saveSettings(ShopSettings(shopName, phone, address, upi)) } }
                })
            }
        }
        ShopCard {
            Text("Change admin password", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Choose a strong password. It signs you in to the shop's online admin account.", fontSize = 12.sp, color = Warn)
            Spacer(Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ShopField(oldPw, { oldPw = it }, "Current password", password = true, keyboardType = KeyboardType.Password)
                ShopField(newPw, { newPw = it }, "New password (min 6 characters)", password = true, keyboardType = KeyboardType.Password)
                PrimaryButton("Change password", onClick = {
                    scope.launch { snack.guard("Password changed") { vm.repo.changePassword(oldPw, newPw); oldPw = ""; newPw = "" } }
                })
            }
        }
    }
}

/** Admin: pick which delivery boy takes a home-delivery order. */
@Composable
private fun AssignDeliveryCard(
    vm: AppViewModel, orderId: Long, currentId: String, currentName: String, currentPhone: String,
    snack: SnackbarHostState, onChanged: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val state by vm.repo.deliveryBoys.state.collectAsStateWithLifecycle()
    ShopCard {
        Text("Delivery boy", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(
            if (currentId.isBlank()) "Not assigned yet" else "🛵 $currentName • $currentPhone",
            color = if (currentId.isBlank()) Warn else GreenOk, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(vertical = 6.dp)
        )
        when (val st = state) {
            is Load.Ok -> {
                if (st.data.isEmpty()) {
                    Text("No delivery boys yet. Add one in the Delivery tab.", fontSize = 12.sp, color = Muted)
                } else {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        st.data.forEach { boy ->
                            FilterChip(
                                selected = boy.id == currentId, label = { Text(boy.name) }, colors = chipColors(),
                                onClick = {
                                    scope.launch { snack.guard("Assigned to ${boy.name}") { vm.repo.assignDelivery(orderId, boy); onChanged() } }
                                }
                            )
                        }
                    }
                    if (currentId.isNotBlank()) {
                        TextButton(onClick = { scope.launch { snack.guard("Delivery boy removed from this order") { vm.repo.assignDelivery(orderId, null); onChanged() } } }) {
                            Text("Un-assign", color = RedPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            is Load.Failed -> Text(st.message, fontSize = 12.sp, color = Warn)
            else -> Text("Loading delivery boys…", fontSize = 12.sp, color = Muted)
        }
    }
}

@Composable
private fun DeliveryBoysTab(vm: AppViewModel, snack: SnackbarHostState) {
    val state by vm.repo.deliveryBoys.state.collectAsStateWithLifecycle()
    val oState by vm.repo.allOrders.state.collectAsStateWithLifecycle()
    val orders = when (val o = oState) { is Load.Ok -> o.data; else -> emptyList() }
    LoadGate(state, { vm.repo.deliveryBoys.refresh() }) { list -> DeliveryBoysContent(vm, snack, list, orders) }
}

@Composable
private fun DeliveryBoysContent(vm: AppViewModel, snack: SnackbarHostState, list: List<UserEntity>, orders: List<OrderWithItems>) {
    val scope = rememberCoroutineScope()
    var adding by remember { mutableStateOf(false) }
    var removing by remember { mutableStateOf<UserEntity?>(null) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PrimaryButton("Add delivery boy", onClick = { adding = true }) }
        if (list.isEmpty()) item { Text("No delivery boys yet. Tap Add delivery boy.", color = Muted) }
        items(list, key = { it.id }) { b ->
            val mine = orders.filter { it.order.deliveryBoyId == b.id }
            val active = mine.count { it.order.status != OrderStatus.DELIVERED.name && it.order.status != OrderStatus.CANCELLED.name }
            val done = mine.count { it.order.status == OrderStatus.DELIVERED.name }
            ShopCard {
                Text("🛵 ${b.name}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(b.phone, color = Muted)
                Text("$active active • $done delivered", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = if (active > 0) RedPrimary else GreenOk)
                TextButton(onClick = { removing = b }) { Text("Remove", color = Color(0xFF616161)) }
            }
        }
    }
    if (adding) AddDeliveryBoyDialog(onDismiss = { adding = false }) { name, phone, pw ->
        adding = false
        scope.launch { snack.guard("Delivery boy added — he can log in with his mobile number") { vm.repo.addDeliveryBoy(name, phone, pw) } }
    }
    removing?.let { cur ->
        AlertDialog(
            onDismissRequest = { removing = null }, containerColor = Color.White,
            title = { Text("Remove ${cur.name}?", fontWeight = FontWeight.Bold) },
            text = { Text("He loses delivery access. His unfinished orders become un-assigned. Delivered orders keep his name.") },
            confirmButton = {
                TextButton(onClick = { removing = null; scope.launch { snack.guard("Removed") { vm.repo.removeDeliveryBoy(cur.id) } } }) {
                    Text("Remove", color = RedPrimary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { removing = null }) { Text("Cancel", color = Muted) } }
        )
    }
}

@Composable
private fun AddDeliveryBoyDialog(onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    val nameErr = com.realsupermarket.app.logic.Validate.name(name)
    val phoneErr = com.realsupermarket.app.logic.Validate.phone(phone)
    val pwErr = com.realsupermarket.app.logic.Validate.password(pw)
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Color.White,
        title = { Text("Add delivery boy", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ShopField(name, { name = it }, "Full name", error = if (show) nameErr else null, capitalization = KeyboardCapitalization.Words)
                ShopField(phone, { phone = it.filter(Char::isDigit).take(10) }, "Mobile number (his login ID)", keyboardType = KeyboardType.Phone, error = if (show) phoneErr else null)
                ShopField(pw, { pw = it }, "Password (min 6 characters)", password = true, keyboardType = KeyboardType.Password, error = if (show) pwErr else null)
                Text("Tell him this mobile number and password. He changes the password himself in his Profile tab.", fontSize = 12.sp, color = Muted)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                show = true
                if (nameErr == null && phoneErr == null && pwErr == null) onSave(name.trim(), phone.trim(), pw)
            }) { Text("Create", color = RedPrimary, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Muted) } }
    )
}
