@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.realsupermarket.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.realsupermarket.app.logic.DraftItem
import com.realsupermarket.app.logic.ListParser
import com.realsupermarket.app.logic.Money
import com.realsupermarket.app.logic.QTY_OPTIONS
import com.realsupermarket.app.logic.QTY_OTHER
import com.realsupermarket.app.ui.AppViewModel
import com.realsupermarket.app.ui.components.BottomAction
import com.realsupermarket.app.ui.components.EmptyState
import com.realsupermarket.app.ui.components.FreeBadge
import com.realsupermarket.app.ui.components.LabeledCheck
import com.realsupermarket.app.ui.components.PrimaryButton
import com.realsupermarket.app.ui.components.ShopCard
import com.realsupermarket.app.ui.components.ShopField
import com.realsupermarket.app.ui.components.ShopTopBar
import com.realsupermarket.app.ui.components.chipColors
import com.realsupermarket.app.ui.components.shopFieldColors
import com.realsupermarket.app.ui.theme.GreenOk
import com.realsupermarket.app.ui.theme.Muted
import com.realsupermarket.app.ui.theme.RedPrimary
import com.realsupermarket.app.ui.theme.Warn

/** Step 1: type the grocery list. Bullets are added automatically. */
@Composable
fun OrderListScreen(vm: AppViewModel, onBack: () -> Unit, onNext: () -> Unit) {
    var showError by remember { mutableStateOf(false) }
    val count = ListParser.lines(vm.draftText.text).size
    Scaffold(
        topBar = {
            ShopTopBar("Order Groceries", onBack) {
                if (vm.draftText.text.isNotBlank()) {
                    TextButton(onClick = { vm.clearDraft() }) { Text("Clear all", color = Color.White, fontWeight = FontWeight.Bold) }
                }
            }
        },
        bottomBar = {
            BottomAction {
                if (showError && count == 0) Text("Please type at least one item to continue", color = Color(0xFFB00020), fontSize = 14.sp)
                PrimaryButton("Add Item Details", onClick = {
                    if (count == 0) showError = true else { vm.buildDraftFromText(); onNext() }
                })
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Type what you need", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Write one item per line. Press Enter for the next item — bullets are added for you.", color = Muted, fontSize = 14.sp)
            OutlinedTextField(
                value = vm.draftText, onValueChange = { vm.onDraftTextChange(it) },
                modifier = Modifier.fillMaxWidth().heightIn(min = 220.dp),
                placeholder = { Text("2 kg rice\n1 litre sunflower oil\n3 packets Parle-G\n500 g toor dal\n2 milk packets", color = Muted) },
                colors = shopFieldColors()
            )
            Text(if (count == 1) "1 item in your list" else "$count items in your list", color = Muted, fontSize = 13.sp)
            Row { FreeBadge() }
        }
    }
}

/** Quantity chips + price for one item. Used on the details screen and in the edit dialog. */
@Composable
fun ItemFields(item: DraftItem, showErrors: Boolean, onChange: (DraftItem) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        ShopField(
            item.name, { onChange(item.copy(name = it)) }, "Item name",
            error = if (showErrors) item.nameError() else null, capitalization = KeyboardCapitalization.Sentences
        )
        Text("Quantity / weight", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            QTY_OPTIONS.forEach { opt ->
                FilterChip(
                    selected = item.qtyChoice == opt && !item.weightUnknown,
                    onClick = { onChange(item.copy(qtyChoice = opt)) },
                    enabled = !item.weightUnknown, label = { Text(opt) }, colors = chipColors()
                )
            }
        }
        if (item.qtyChoice == QTY_OTHER && !item.weightUnknown) {
            ShopField(
                item.customQty, { onChange(item.copy(customQty = it)) }, "Quantity (e.g. 750 g)",
                error = if (showErrors) item.qtyError() else null
            )
        } else if (showErrors && item.qtyError() != null) {
            Text(item.qtyError()!!, color = Color(0xFFB00020), fontSize = 12.sp)
        }
        LabeledCheck(item.weightUnknown, { onChange(item.copy(weightUnknown = it)) }, "Weight not sure")
        ShopField(
            item.priceText,
            { if (Regex("^[0-9]{0,6}(\\.[0-9]{0,2})?$").matches(it)) onChange(item.copy(priceText = it)) },
            if (item.priceUnknown) "Price unknown" else "Price", prefix = "₹",
            error = if (showErrors) item.priceError() else null,
            keyboardType = KeyboardType.Decimal, enabled = !item.priceUnknown
        )
        LabeledCheck(item.priceUnknown, { onChange(item.copy(priceUnknown = it)) }, "I don't know the price")
    }
}

/** Step 2: weight and price for every item. */
@Composable
fun ItemDetailsScreen(vm: AppViewModel, onBack: () -> Unit, onNext: () -> Unit) {
    var showErrors by remember { mutableStateOf(false) }
    val bad = vm.draft.any { !it.isValid }
    Scaffold(
        topBar = { ShopTopBar("Item Details", onBack) },
        bottomBar = {
            BottomAction {
                if (showErrors && bad) Text("Some items need attention — please check the red messages.", color = Color(0xFFB00020), fontSize = 14.sp)
                PrimaryButton("Review Order", onClick = { if (bad) showErrors = true else onNext() }, enabled = vm.draft.isNotEmpty())
            }
        }
    ) { pad ->
        if (vm.draft.isEmpty()) {
            Column(Modifier.padding(pad)) { EmptyState("📝", "No items", "Go back and type your grocery list.", "Back", onBack) }
        } else {
            LazyColumn(
                Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item { Text("Add weight and price for each item. If you're not sure, just tick the box.", color = Muted, fontSize = 14.sp) }
                items(vm.draft, key = { it.key }) { item ->
                    ShopCard {
                        Row(Modifier.fillMaxWidth()) {
                            Text("Item", fontWeight = FontWeight.Bold, color = RedPrimary, modifier = Modifier.weight(1f))
                            TextButton(onClick = { vm.removeItem(item.key) }) { Text("Remove", color = RedPrimary) }
                        }
                        ItemFields(item, showErrors) { vm.updateItem(it) }
                    }
                }
            }
        }
    }
}

/** Step 3: review every item, edit or remove, then continue. */
@Composable
fun ReviewScreen(vm: AppViewModel, onBack: () -> Unit, onCheckout: () -> Unit, onStartOrder: () -> Unit) {
    var editing by remember { mutableStateOf<DraftItem?>(null) }
    val known = vm.draft.mapNotNull { it.price }.sum()
    val unknown = vm.draft.count { it.price == null }
    Scaffold(
        topBar = { ShopTopBar("Review Order", onBack) },
        bottomBar = {
            if (vm.draft.isNotEmpty()) BottomAction { PrimaryButton("Review & Complete Order", onClick = onCheckout) }
        }
    ) { pad ->
        if (vm.draft.isEmpty()) {
            Column(Modifier.padding(pad)) { EmptyState("🛒", "Your list is empty", "Add some groceries to continue.", "Start an Order", onStartOrder) }
        } else {
            LazyColumn(
                Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(vm.draft, key = { it.key }) { item ->
                    ShopCard {
                        Text(item.name, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text("Weight: ${if (item.weightUnknown) "not sure" else item.qtyLabel}", fontSize = 14.sp)
                        val p = item.price
                        if (p != null) Text("Price: ${Money.fmt(p)}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        else Text("Price: don't know (to be confirmed)", fontSize = 14.sp, color = Warn, fontWeight = FontWeight.SemiBold)
                        Row(Modifier.fillMaxWidth()) {
                            TextButton(onClick = { editing = item }) { Text("Edit", color = RedPrimary, fontWeight = FontWeight.Bold) }
                            Spacer(Modifier.width(8.dp))
                            TextButton(onClick = { vm.removeItem(item.key) }) { Text("Remove", color = Color(0xFF616161)) }
                        }
                    }
                }
                item { SummaryCard(vm.draft.size, known, unknown) }
            }
        }
    }
    editing?.let { cur ->
        EditItemDialog(cur, onDismiss = { editing = null }, onSave = { vm.updateItem(it); editing = null })
    }
}

@Composable
fun SummaryCard(count: Int, known: Double, unknown: Int) {
    ShopCard {
        Row(Modifier.fillMaxWidth()) {
            Text("Items", modifier = Modifier.weight(1f)); Text("$count", fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth()) {
            Text("Items subtotal", modifier = Modifier.weight(1f)); Text(Money.fmt(known), fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text("Delivery", modifier = Modifier.weight(1f)); Text("FREE", color = GreenOk, fontWeight = FontWeight.ExtraBold)
        }
        HorizontalDivider(Modifier.padding(vertical = 10.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.Top) {
            Text("Estimated total", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.45f))
            Text(Money.total(known, unknown), fontWeight = FontWeight.ExtraBold, color = RedPrimary, fontSize = 17.sp, modifier = Modifier.weight(0.55f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
        }
        if (unknown > 0) {
            Spacer(Modifier.height(6.dp))
            Text("$unknown item${if (unknown > 1) "s have" else " has"} no price yet. The shop will confirm the final amount.", fontSize = 12.sp, color = Warn)
        }
    }
}

@Composable
private fun EditItemDialog(cur: DraftItem, onDismiss: () -> Unit, onSave: (DraftItem) -> Unit) {
    var tmp by remember { mutableStateOf(cur) }
    var show by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Color.White,
        title = { Text("Edit item", fontWeight = FontWeight.Bold) },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { ItemFields(tmp, show) { tmp = it } } },
        confirmButton = {
            TextButton(onClick = { if (tmp.isValid) onSave(tmp) else show = true }) { Text("Save", color = RedPrimary, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Muted) } }
    )
}
