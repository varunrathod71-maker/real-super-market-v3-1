package com.realsupermarket.app.data

import org.json.JSONArray
import org.json.JSONObject

internal fun JSONArray.objects(): List<JSONObject> = List(length()) { getJSONObject(it) }
private fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k, "")
private fun JSONObject.dbl(k: String): Double = if (isNull(k)) 0.0 else optDouble(k, 0.0)

internal fun userFrom(j: JSONObject) = UserEntity(
    id = j.str("id"), name = j.str("name"), phone = j.str("phone"),
    role = j.str("role").uppercase().ifBlank { Role.CUSTOMER },
    createdAt = j.optLong("created_ms", 0L)
)

internal fun productFrom(j: JSONObject) = ProductEntity(
    id = j.getLong("id"), name = j.str("name"), description = j.str("description"), category = j.str("category"),
    price = j.dbl("price"), stock = j.dbl("stock"), unit = j.str("unit").ifBlank { "kg" },
    emoji = j.str("emoji").ifBlank { "🛒" }, active = j.optBoolean("active", true), loose = j.optBoolean("loose", false)
)

internal fun itemFrom(j: JSONObject) = OrderItemEntity(
    id = j.getLong("id"), orderId = j.getLong("order_id"), name = j.str("name"), qtyLabel = j.str("qty_label"),
    qtyUnknown = j.optBoolean("qty_unknown", false),
    price = if (j.isNull("price")) null else j.getDouble("price"),   // NULL stays null, never 0
    productId = if (j.isNull("product_id")) null else j.getLong("product_id")
)

internal fun orderFrom(j: JSONObject): OrderWithItems {
    val order = OrderEntity(
        id = j.getLong("id"), orderNo = j.str("order_no"), userId = j.str("user_id"),
        customerName = j.str("customer_name"), phone = j.str("phone"), fulfillment = j.str("fulfillment"),
        address = j.str("address"), payment = j.str("payment"),
        paymentConfirmed = j.optBoolean("payment_confirmed", false), status = j.str("status"),
        subtotal = j.dbl("subtotal"), unknownCount = j.optInt("unknown_count", 0),
        deliveryFee = j.dbl("delivery_fee"), createdAt = j.optLong("created_ms", 0L),
        deliveryBoyId = j.str("delivery_boy_id"), deliveryBoyName = j.str("delivery_boy_name"),
        deliveryBoyPhone = j.str("delivery_boy_phone"), deliveredAt = if (j.isNull("delivered_ms")) 0L else j.optLong("delivered_ms", 0L)
    )
    val items = j.optJSONArray("order_items")?.objects().orEmpty().map { itemFrom(it) }.sortedBy { it.id }
    return OrderWithItems(order, items)
}
