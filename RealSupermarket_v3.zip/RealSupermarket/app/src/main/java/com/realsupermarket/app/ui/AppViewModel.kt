package com.realsupermarket.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.realsupermarket.app.ShopApp
import com.realsupermarket.app.data.Load
import com.realsupermarket.app.data.PlaceOrderRequest
import com.realsupermarket.app.data.ProductEntity
import com.realsupermarket.app.data.Role
import com.realsupermarket.app.data.ShopRepository
import com.realsupermarket.app.data.ShopSettings
import com.realsupermarket.app.data.UserEntity
import com.realsupermarket.app.logic.Bullets
import com.realsupermarket.app.logic.DraftItem
import com.realsupermarket.app.logic.ListParser
import com.realsupermarket.app.logic.QTY_OPTIONS
import com.realsupermarket.app.logic.QTY_OTHER
import com.realsupermarket.app.logic.fmtNum
import com.realsupermarket.app.net.ApiException
import java.util.UUID
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Holds the order being built (draft) and session info. Persistent data lives in the cloud (see [ShopRepository]). */
class AppViewModel(app: Application) : AndroidViewModel(app) {
    val repo: ShopRepository = (app as ShopApp).repo

    var startRoute by mutableStateOf<String?>(null)
        private set

    val currentUser: StateFlow<UserEntity?> = repo.currentUser
    val settings: StateFlow<ShopSettings> = repo.settingsPoller.state
        .map { s -> when (s) { is Load.Ok -> s.data; else -> ShopSettings() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ShopSettings())

    init {
        viewModelScope.launch {
            val u = repo.currentUser.value
            startRoute = when {
                !repo.configured -> "setup"
                u == null -> "login"
                u.role == Role.ADMIN -> "admin"
                u.role == Role.DELIVERY -> "delivery"
                else -> "home"
            }
            if (u != null && repo.configured) {
                try { repo.loadProfile() } catch (e: Exception) { /* offline at start: keep the saved profile */ }
            }
        }
    }

    fun logout() {
        repo.logout()
        clearDraft()
    }

    // ---------------- draft order
    var draftText by mutableStateOf(TextFieldValue(""))
        private set
    val draft = mutableStateListOf<DraftItem>()
    private var lastBuilt: String? = null
    private var orderRef: String? = null   // same ref on retries => the server never creates a duplicate order

    fun onDraftTextChange(new: TextFieldValue) {
        orderRef = null
        draftText = Bullets.apply(draftText, new)
    }

    /** Creates one item per typed line, keeping details already entered for unchanged lines. */
    fun buildDraftFromText() {
        val text = draftText.text
        if (text == lastBuilt && draft.isNotEmpty()) return
        val old = draft.toList()
        val used = HashSet<String>()
        val rebuilt = ListParser.lines(text).map { line ->
            val match = old.firstOrNull { it.key !in used && it.source.equals(line, ignoreCase = true) }
            if (match != null) { used += match.key; match } else ListParser.toItem(line)
        }
        draft.clear()
        draft.addAll(rebuilt)
        lastBuilt = text
    }

    fun updateItem(item: DraftItem) {
        orderRef = null
        val i = draft.indexOfFirst { it.key == item.key }
        if (i >= 0) draft[i] = item
    }

    fun removeItem(key: String) {
        orderRef = null
        val item = draft.firstOrNull { it.key == key } ?: return
        draft.remove(item)
        val lines = draftText.text.lines().toMutableList()
        val idx = lines.indexOfFirst { ListParser.stripBullet(it).equals(item.source, ignoreCase = true) }
        if (idx >= 0) lines.removeAt(idx)
        draftText = TextFieldValue(lines.joinToString("\n"))
        lastBuilt = draftText.text
    }

    fun addProduct(p: ProductEntity) {
        orderRef = null
        buildDraftFromText()
        val label = "1 ${p.unit}"
        val known = label in QTY_OPTIONS
        draft.add(
            DraftItem(
                name = p.name, source = p.name,
                qtyChoice = if (known) label else QTY_OTHER, customQty = if (known) "" else label,
                priceText = fmtNum(p.price), productId = p.id
            )
        )
        val t = draftText.text
        draftText = TextFieldValue(if (t.isBlank()) "• ${p.name}" else t.trimEnd() + "\n• ${p.name}")
        lastBuilt = draftText.text
    }

    fun clearDraft() {
        orderRef = null
        draft.clear()
        draftText = TextFieldValue("")
        lastBuilt = null
    }

    // ---------------- placing the order
    var placing by mutableStateOf(false)
        private set
    var placeError by mutableStateOf<String?>(null)
        private set

    fun placeOrder(fulfillment: String, name: String, phone: String, address: String, payment: String, onDone: (Long) -> Unit) {
        if (placing) return
        placing = true
        placeError = null
        viewModelScope.launch {
            try {
                val ref = orderRef ?: UUID.randomUUID().toString().also { orderRef = it }
                val id = repo.placeOrder(PlaceOrderRequest(draft.map { it.toLine() }, fulfillment, name, phone, address, payment, ref))
                clearDraft()
                onDone(id)
            } catch (e: IllegalArgumentException) {
                placeError = e.message
            } catch (e: ApiException) {
                placeError = (e.message ?: "We couldn't save your order.") + " Your list is safe - tap Retry."
            } catch (e: Exception) {
                placeError = "We couldn't save your order. Your list is safe - please tap Retry."
            } finally {
                placing = false
            }
        }
    }
}
