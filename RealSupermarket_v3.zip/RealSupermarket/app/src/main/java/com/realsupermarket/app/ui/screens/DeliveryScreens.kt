@file:OptIn(ExperimentalMaterial3Api::class)

package com.realsupermarket.app.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.realsupermarket.app.data.Load
import com.realsupermarket.app.data.OrderLookup
import com.realsupermarket.app.data.OrderStatus
import com.realsupermarket.app.data.OrderWithItems
import com.realsupermarket.app.data.Payment
import com.realsupermarket.app.data.Role
import com.realsupermarket.app.logic.DateFmt
import com.realsupermarket.app.logic.Money
import com.realsupermarket.app.ui.AppViewModel
import com.realsupermarket.app.ui.components.BottomAction
import com.realsupermarket.app.ui.components.EmptyState
import com.realsupermarket.app.ui.components.FreeBadge
import com.realsupermarket.app.ui.components.InfoRow
import com.realsupermarket.app.ui.components.LabeledCheck
import com.realsupermarket.app.ui.components.LoadGate
import com.realsupermarket.app.ui.components.PrimaryButton
import com.realsupermarket.app.ui.components.SecondaryButton
import com.realsupermarket.app.ui.components.ShopCard
import com.realsupermarket.app.ui.components.ShopField
import com.realsupermarket.app.ui.components.ShopTopBar
import com.realsupermarket.app.ui.components.StatusChip
import com.realsupermarket.app.ui.components.guard
import com.realsupermarket.app.ui.theme.GreenOk
import com.realsupermarket.app.ui.theme.Muted
import com.realsupermarket.app.ui.theme.RedDark
import com.realsupermarket.app.ui.theme.RedLight
import com.realsupermarket.app.ui.theme.RedPrimary
import com.realsupermarket.app.ui.theme.Warn
import kotlinx.coroutines.launch
import java.util.Calendar

private fun isClosed(o: OrderWithItems) =
    o.order.status == OrderStatus.DELIVERED.name || o.order.status == OrderStatus.CANCELLED.name

private fun startOfToday(): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

private fun openDialer(ctx: Context, phone: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone.trim()))) } catch (e: Exception) { /* no dialer on this device */ }
}

private fun openMaps(ctx: Context, address: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(address))))
    } catch (e: Exception) { /* no maps app on this device */ }
}

// ============================================================ main screen (3 tabs)

@Composable
fun DeliveryMain(vm: AppViewModel, onOpenOrder: (Long) -> Unit, onLogout: () -> Unit) {
    val user by vm.currentUser.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val snack = remember { SnackbarHostState() }
    val tabs = listOf("Active" to Icons.Filled.Home, "Delivered" to Icons.AutoMirrored.Filled.List, "Profile" to Icons.Filled.Person)
    Scaffold(
        topBar = {
            ShopTopBar(title = when (tab) { 0 -> "Delivery Panel"; 1 -> "Delivered Orders"; else -> "My Profile" }) {
                if (tab != 2) {
                    TextButton(onClick = { vm.repo.myDeliveries.refresh() }) { Text("Refresh", color = Color.White, fontWeight = FontWeight.Bold) }
                }
            }
        },
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icon, contentDescription = label) }, label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White, selectedTextColor = RedPrimary,
                            indicatorColor = RedPrimary, unselectedIconColor = Muted, unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (user != null && user?.role != Role.DELIVERY) {
                EmptyState("🔒", "Delivery access only", "This area is only for the shop's delivery staff.", "Log out", onLogout)
            } else {
                when (tab) {
                    0 -> ActiveTab(vm, onOpenOrder)
                    1 -> DeliveredTab(vm, onOpenOrder)
                    else -> DeliveryProfileTab(vm, snack, onLogout)
                }
            }
        }
    }
}

@Composable
private fun DeliveryStat(title: String, value: String, modifier: Modifier) {
    Card(
        modifier = modifier, shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = RedPrimary)
        }
    }
}

/** What the delivery boy must collect from the customer at the door. */
private fun collectText(o: OrderWithItems): String? {
    val order = o.order
    if (order.payment != Payment.CASH || order.paymentConfirmed) return null
    return "Collect cash: " + Money.total(order.subtotal, order.unknownCount)
}

@Composable
private fun DeliveryOrderCard(o: OrderWithItems, onClick: () -> Unit) {
    val order = o.order
    val status = OrderStatus.from(order.status)
    Card(
        onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("#${order.orderNo}", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                StatusChip(status)
            }
            Text(DateFmt.full(order.createdAt), fontSize = 12.sp, color = Muted)
            Spacer(Modifier.height(8.dp))
            Text("${order.customerName} • ${order.phone}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text("📍 ${order.address}", fontSize = 13.sp, color = Muted, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(8.dp))
            val collect = collectText(o)
            Text(
                collect ?: if (order.payment == Payment.UPI) "UPI order — nothing to collect" else "Cash — already received",
                fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (collect != null) RedPrimary else GreenOk
            )
        }
    }
}

@Composable
private fun ActiveTab(vm: AppViewModel, onOpenOrder: (Long) -> Unit) {
    val state by vm.repo.myDeliveries.state.collectAsStateWithLifecycle()
    LoadGate(state, { vm.repo.myDeliveries.refresh() }) { all -> ActiveContent(all, onOpenOrder) }
}

@Composable
private fun ActiveContent(all: List<OrderWithItems>, onOpenOrder: (Long) -> Unit) {
    val active = all.filter { !isClosed(it) }
        .sortedWith(compareBy({ if (it.order.status == OrderStatus.OUT_FOR_DELIVERY.name) 0 else 1 }, { it.order.createdAt }))
    val out = active.count { it.order.status == OrderStatus.OUT_FOR_DELIVERY.name }
    val today = startOfToday()
    val doneToday = all.count { it.order.status == OrderStatus.DELIVERED.name && it.order.deliveredAt >= today }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                DeliveryStat("To deliver", "${active.size}", Modifier.weight(1f))
                DeliveryStat("On the way", "$out", Modifier.weight(1f))
                DeliveryStat("Done today", "$doneToday", Modifier.weight(1f))
            }
        }
        if (active.isEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().padding(top = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🛵", fontSize = 52.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("No deliveries right now", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Orders the shop assigns to you will appear here automatically.", color = Muted, textAlign = TextAlign.Center)
                }
            }
        }
        items(active, key = { it.order.id }) { o -> DeliveryOrderCard(o) { onOpenOrder(o.order.id) } }
    }
}

@Composable
private fun DeliveredTab(vm: AppViewModel, onOpenOrder: (Long) -> Unit) {
    val state by vm.repo.myDeliveries.state.collectAsStateWithLifecycle()
    LoadGate(state, { vm.repo.myDeliveries.refresh() }) { all -> DeliveredContent(all, onOpenOrder) }
}

@Composable
private fun DeliveredContent(all: List<OrderWithItems>, onOpenOrder: (Long) -> Unit) {
    val done = all.filter { it.order.status == OrderStatus.DELIVERED.name }.sortedByDescending { it.order.deliveredAt }
    val today = startOfToday()
    val todays = done.filter { it.order.deliveredAt >= today }
    val cashToday = todays.filter { it.order.payment == Payment.CASH && it.order.paymentConfirmed }.sumOf { it.order.subtotal }
    if (done.isEmpty()) { EmptyState("📦", "Nothing delivered yet", "Finished deliveries will be listed here."); return }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                DeliveryStat("Delivered today", "${todays.size}", Modifier.weight(1f))
                DeliveryStat("Cash collected today", Money.fmt(cashToday), Modifier.weight(1f))
            }
        }
        item { Text("Cash is the known item total. Hand it to the shop at the end of the day.", fontSize = 12.sp, color = Muted) }
        items(done, key = { it.order.id }) { o ->
            Card(
                onClick = { onOpenOrder(o.order.id) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text("#${o.order.orderNo} • ${o.order.customerName}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(if (o.order.deliveredAt > 0) DateFmt.full(o.order.deliveredAt) else DateFmt.full(o.order.createdAt), fontSize = 12.sp, color = Muted)
                        Text(paymentLabel(o.order), fontSize = 12.sp, color = if (o.order.paymentConfirmed) GreenOk else Warn)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        Money.total(o.order.subtotal, o.order.unknownCount), fontWeight = FontWeight.Bold, color = RedPrimary,
                        fontSize = 14.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.6f)
                    )
                }
            }
        }
    }
}

@Composable
private fun DeliveryProfileTab(vm: AppViewModel, snack: SnackbarHostState, onLogout: () -> Unit) {
    val user by vm.currentUser.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var oldPw by remember { mutableStateOf("") }
    var newPw by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ShopCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(56.dp).clip(CircleShape).background(RedLight), contentAlignment = Alignment.Center) {
                    Text((user?.name?.firstOrNull() ?: 'D').uppercase(), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = RedPrimary)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(user?.name ?: "", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(user?.phone ?: "", color = Muted)
                    Text("🛵 Delivery partner", color = RedDark, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        ShopCard {
            Text(settings.shopName, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            FreeBadge()
            if (settings.address.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(settings.address, color = Muted) }
            if (settings.phone.isNotBlank()) Text("Shop phone: ${settings.phone}", color = Muted)
        }
        ShopCard {
            Text("Change password", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ShopField(oldPw, { oldPw = it }, "Current password", password = true, keyboardType = KeyboardType.Password)
                ShopField(newPw, { newPw = it }, "New password (min 6 characters)", password = true, keyboardType = KeyboardType.Password)
                PrimaryButton("Change password", onClick = {
                    scope.launch { snack.guard("Password changed") { vm.repo.changePassword(oldPw, newPw); oldPw = ""; newPw = "" } }
                })
            }
        }
        SecondaryButton("Log out", onLogout)
    }
}

// ============================================================ one order (start / finish delivery)

@Composable
fun DeliveryOrderScreen(vm: AppViewModel, orderId: Long, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val poller = remember(orderId) { vm.repo.orderPoller(orderId) }
    val state by poller.state.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var confirming by remember { mutableStateOf(false) }
    var cashGot by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }

    val found: OrderWithItems? = when (val st = state) {
        is Load.Ok -> (st.data as? OrderLookup.Found)?.order
        else -> null
    }

    Scaffold(
        topBar = {
            ShopTopBar("Delivery Details", onBack) {
                TextButton(onClick = { poller.refresh() }) { Text("Refresh", color = Color.White, fontWeight = FontWeight.Bold) }
            }
        },
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            val f = found
            val o = f?.order
            if (f != null && o != null && !isClosed(f)) {
                BottomAction {
                    when (OrderStatus.from(o.status)) {
                        OrderStatus.PLACED, OrderStatus.CONFIRMING -> {
                            Text("Waiting for the shop to confirm this order.", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                            PrimaryButton("Start delivery", onClick = {}, enabled = false)
                        }
                        OrderStatus.OUT_FOR_DELIVERY -> PrimaryButton("Mark as delivered", onClick = { cashGot = true; confirming = true }, loading = busy)
                        else -> PrimaryButton("Start delivery", loading = busy, onClick = {
                            scope.launch {
                                busy = true
                                snack.guard("Out for delivery — drive safe!") { vm.repo.startDelivery(o.id); poller.refresh() }
                                busy = false
                            }
                        })
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            LoadGate(state, onRetry = { poller.refresh() }) { l ->
                when (l) {
                    is OrderLookup.Missing -> EmptyState("🔒", "Not available", "This order isn't assigned to you.", "Back", onBack)
                    is OrderLookup.Found -> {
                        val o = l.order.order
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            ShopCard {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Order #${o.orderNo}", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                                    StatusChip(OrderStatus.from(o.status))
                                }
                                Text(DateFmt.full(o.createdAt), fontSize = 12.sp, color = Muted)
                            }
                            ShopCard {
                                Text("Deliver to", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Spacer(Modifier.height(6.dp))
                                InfoRow("Name", o.customerName)
                                InfoRow("Phone", o.phone)
                                InfoRow("Address", o.address)
                                Spacer(Modifier.height(10.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    SecondaryButton("📞 Call", onClick = { openDialer(ctx, o.phone) }, modifier = Modifier.weight(1f))
                                    SecondaryButton("🗺 Map", onClick = { openMaps(ctx, o.address) }, modifier = Modifier.weight(1f))
                                }
                            }
                            ShopCard {
                                Text("Payment", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text(paymentLabel(o), modifier = Modifier.padding(vertical = 6.dp))
                                val collect = collectText(l.order)
                                if (collect != null && !isClosed(l.order)) {
                                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(RedLight).padding(12.dp)) {
                                        Text(collect, fontWeight = FontWeight.ExtraBold, color = RedPrimary, fontSize = 16.sp)
                                    }
                                    if (o.unknownCount > 0) {
                                        Spacer(Modifier.height(6.dp))
                                        Text("Some prices are \"to be confirmed\". Ask the shop for the final amount before collecting.", fontSize = 12.sp, color = Warn)
                                    }
                                } else if (o.payment == Payment.UPI && !isClosed(l.order)) {
                                    Text("Paid by UPI — the shop confirms it. Do not collect cash.", fontSize = 12.sp, color = Muted)
                                }
                            }
                            BillCard(l.order, settings.shopName)
                        }
                    }
                }
            }
        }
    }

    val dlgOrder = found
    if (confirming && dlgOrder != null) {
        val o = dlgOrder.order
        val needsCash = o.payment == Payment.CASH && !o.paymentConfirmed
        AlertDialog(
            onDismissRequest = { confirming = false }, containerColor = Color.White,
            title = { Text("Delivered to ${o.customerName}?", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("This tells the shop and the customer that the order has reached the customer.")
                    if (needsCash) {
                        Spacer(Modifier.height(10.dp))
                        Text(collectText(dlgOrder) ?: "", fontWeight = FontWeight.Bold, color = RedPrimary)
                        LabeledCheck(cashGot, { cashGot = it }, "I collected the cash")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    confirming = false
                    scope.launch {
                        busy = true
                        snack.guard("Delivered — well done!") { vm.repo.finishDelivery(o.id, needsCash && cashGot); poller.refresh() }
                        busy = false
                    }
                }) { Text("Yes, delivered", color = RedPrimary, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { confirming = false }) { Text("Cancel", color = Muted) } }
        )
    }
}
