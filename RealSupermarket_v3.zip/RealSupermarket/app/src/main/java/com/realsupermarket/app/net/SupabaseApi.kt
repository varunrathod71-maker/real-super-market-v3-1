package com.realsupermarket.app.net

import android.content.Context
import com.realsupermarket.app.BuildConfig
import com.realsupermarket.app.data.UserEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** A friendly error. [offline] = true when the phone could not reach the server. */
class ApiException(message: String, val offline: Boolean = false, val status: Int = 0) : Exception(message)

/**
 * Remembers ONLY the login session (tokens + who is signed in) so the user stays logged in.
 * All orders, products, customers and settings live in Supabase, never on the phone.
 */
class SessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("session_v2", Context.MODE_PRIVATE)
    private val _user = MutableStateFlow(loadUser())
    val user: StateFlow<UserEntity?> = _user

    val accessToken: String? get() = prefs.getString("at", null)
    val refreshToken: String? get() = prefs.getString("rt", null)
    val expiresAt: Long get() = prefs.getLong("exp", 0L)
    val userId: String? get() = prefs.getString("uid", null)
    var email: String?
        get() = prefs.getString("email", null)
        set(v) { prefs.edit().putString("email", v).apply() }

    fun saveTokens(access: String, refresh: String, expiresInSec: Long, userId: String? = null) {
        val e = prefs.edit()
            .putString("at", access).putString("rt", refresh)
            .putLong("exp", System.currentTimeMillis() + expiresInSec * 1000)
        if (userId != null) e.putString("uid", userId)
        e.apply()
    }

    fun saveUser(u: UserEntity) {
        prefs.edit().putString("uid", u.id).putString("name", u.name).putString("phone", u.phone)
            .putString("role", u.role).putLong("created", u.createdAt).apply()
        _user.value = u
    }

    fun clear() {
        prefs.edit().clear().apply()
        _user.value = null
    }

    private fun loadUser(): UserEntity? {
        val id = prefs.getString("uid", null) ?: return null
        if (prefs.getString("at", null) == null) return null
        return UserEntity(
            id, prefs.getString("name", "") ?: "", prefs.getString("phone", "") ?: "",
            prefs.getString("role", "CUSTOMER") ?: "CUSTOMER", prefs.getLong("created", 0L)
        )
    }
}

/** Minimal Supabase client (REST + Auth) over OkHttp. */
class SupabaseApi(private val session: SessionStore) {
    val configured: Boolean = BuildConfig.SUPABASE_URL.isNotBlank() && BuildConfig.SUPABASE_ANON_KEY.isNotBlank()
    private val base = BuildConfig.SUPABASE_URL.trim().trimEnd('/')
    private val anon = BuildConfig.SUPABASE_ANON_KEY.trim()
    private val jsonType = "application/json; charset=utf-8".toMediaType()
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(25, TimeUnit.SECONDS).writeTimeout(25, TimeUnit.SECONDS)
        .build()
    private val refreshLock = Mutex()

    private class Raw(val code: Int, val body: String)

    suspend fun get(path: String): String = call("GET", path)
    suspend fun post(path: String, body: String, prefer: String? = null, authed: Boolean = true): String =
        call("POST", path, body, authed, prefer)
    suspend fun patch(path: String, body: String, prefer: String? = null): String = call("PATCH", path, body, true, prefer)
    suspend fun put(path: String, body: String): String = call("PUT", path, body, true, null)
    suspend fun delete(path: String, prefer: String? = null): String = call("DELETE", path, null, true, prefer)

    private suspend fun call(method: String, path: String, body: String?, authed: Boolean, prefer: String?): String {
        if (!configured) {
            throw ApiException("This app build has no Supabase connection (SUPABASE_URL / SUPABASE_ANON_KEY missing).")
        }
        if (authed) ensureFreshToken()
        var res = execute(method, path, body, authed, prefer)
        if (res.code == 401 && authed && session.refreshToken != null && refreshTokens()) {
            res = execute(method, path, body, authed, prefer)
        }
        if (res.code !in 200..299) throw ApiException(friendlyError(res.code, res.body), status = res.code)
        return res.body
    }

    private suspend fun execute(method: String, path: String, body: String?, authed: Boolean, prefer: String?): Raw =
        withContext(Dispatchers.IO) {
            val rb = Request.Builder().url(base + path).header("apikey", anon).header("Accept", "application/json")
            val bearer = if (authed && session.accessToken != null) session.accessToken
            else if (anon.startsWith("eyJ")) anon else null
            if (bearer != null) rb.header("Authorization", "Bearer $bearer")
            if (prefer != null) rb.header("Prefer", prefer)
            val payload = when {
                body != null -> body.toRequestBody(jsonType)
                method == "POST" || method == "PUT" || method == "PATCH" -> "".toRequestBody(jsonType)
                else -> null
            }
            rb.method(method, payload)
            try {
                http.newCall(rb.build()).execute().use { r -> Raw(r.code, r.body?.string().orEmpty()) }
            } catch (e: IOException) {
                throw ApiException("No internet connection or the server is unreachable. Check your connection and tap Retry.", offline = true)
            }
        }

    private suspend fun ensureFreshToken() {
        if (session.accessToken == null) throw ApiException("Please log in again.", status = 401)
        if (System.currentTimeMillis() > session.expiresAt - 60_000) refreshTokens()
    }

    private suspend fun refreshTokens(): Boolean {
        return refreshLock.withLock {
            val rt = session.refreshToken
            if (rt == null) {
                false
            } else {
                val raw = execute("POST", "/auth/v1/token?grant_type=refresh_token", JSONObject().put("refresh_token", rt).toString(), false, null)
                if (raw.code !in 200..299) {
                    false
                } else {
                    val j = JSONObject(raw.body)
                    session.saveTokens(j.getString("access_token"), j.getString("refresh_token"), j.optLong("expires_in", 3600))
                    true
                }
            }
        }
    }

    private fun friendlyError(code: Int, body: String): String {
        val msg = try {
            val j = JSONObject(body)
            j.optString("message").ifBlank { j.optString("msg") }
                .ifBlank { j.optString("error_description") }.ifBlank { j.optString("error") }
        } catch (e: Exception) {
            ""
        }
        return when {
            msg.contains("Invalid login credentials", true) -> "Wrong mobile number or password."
            msg.contains("already registered", true) || msg.contains("already been registered", true) ->
                "This mobile number is already registered. Please log in."
            code == 401 -> "Your session has expired. Please log out and log in again."
            code == 403 -> if (msg.isBlank()) "You are not allowed to do that." else msg
            msg.isNotBlank() -> msg
            else -> "Server error ($code). Please try again."
        }
    }
}
