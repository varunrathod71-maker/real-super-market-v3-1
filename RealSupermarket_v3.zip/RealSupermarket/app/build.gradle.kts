plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.realsupermarket.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.realsupermarket.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "2.0"

        // Backend connection. Supplied at build time (GitHub secrets / environment) - never hard-coded.
        val sbUrl = System.getenv("SUPABASE_URL") ?: (project.findProperty("SUPABASE_URL") as String?) ?: ""
        val sbKey = System.getenv("SUPABASE_ANON_KEY") ?: (project.findProperty("SUPABASE_ANON_KEY") as String?) ?: ""
        val sbDomain = (System.getenv("CUSTOMER_EMAIL_DOMAIN") ?: (project.findProperty("CUSTOMER_EMAIL_DOMAIN") as String?) ?: "")
            .trim().ifBlank { "gmail.com" }
        buildConfigField("String", "SUPABASE_URL", "\"${sbUrl.trim()}\"")
        buildConfigField("String", "SUPABASE_ANON_KEY", "\"${sbKey.trim()}\"")
        buildConfigField("String", "CUSTOMER_EMAIL_DOMAIN", "\"$sbDomain\"")
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
