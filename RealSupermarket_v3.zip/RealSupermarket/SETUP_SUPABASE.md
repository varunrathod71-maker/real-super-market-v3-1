# Supabase setup (about 10 minutes, all from a phone browser)

1. supabase.com > New project (any name, set a database password, pick a region near you). Wait until it is ready.
2. SQL Editor > New query > paste the whole of `supabase/schema.sql` > Run. (Safe to run again.)
3. Authentication > Sign In / Providers > Email: turn OFF "Confirm email" > Save.
4. Create the admin: Authentication > Users > Add user > Create new user. Email = your admin email, a strong password, tick "Auto Confirm User".
5. SQL Editor, run (change the email):
   update public.profiles set role = 'admin', name = 'Shop Admin'
   where id = (select id from auth.users where email = 'YOUR_ADMIN_EMAIL');
6. Project Settings > API (or "API Keys"): copy the Project URL and the anon / publishable key.
   NEVER use the service_role / secret key in this app.
7. GitHub repo > Settings > Secrets and variables > Actions > New repository secret:
   SUPABASE_URL = the Project URL (https://xxxx.supabase.co)
   SUPABASE_ANON_KEY = the anon / publishable key
   (optional) CUSTOMER_EMAIL_DOMAIN = defaults to gmail.com. Customers sign in with their mobile number;
   Supabase needs an email, so the app uses <mobile>@<this domain> behind the scenes (no email is ever sent).
8. Run the "Build APK" workflow, install the APK on BOTH phones.
   Customer phone: Sign up with a mobile number. Admin phone: Login with the ADMIN EMAIL + password.

Optional backend self-test from Termux (pkg install curl jq):
   bash tools/e2e_check.sh https://xxxx.supabase.co YOUR_ANON_KEY admin@email.com ADMIN_PASSWORD

## Delivery boy panel (new)
1. SQL Editor > run the NEW `supabase/schema.sql` again (it is safe to re-run; it adds the delivery role, order columns and functions).
2. SQL Editor > run `supabase/create_delivery_boy.sql`. It creates the first delivery boy:
   Login ID: deliveryboy123   Password: delivery123
   (type the login ID in the "Mobile number or email" box on the login screen; if you changed CUSTOMER_EMAIL_DOMAIN, edit v_email in the SQL to match)
3. More delivery boys: Admin > Delivery tab > "Add delivery boy" (name, mobile number, password). Nothing to run in Supabase.
4. Give a home-delivery order to a delivery boy: Admin > Orders > open the order > "Delivery boy" card.
5. The delivery boy sees only the orders assigned to him, taps "Start delivery", then "Mark as delivered"
   (and confirms the cash he collected for Cash orders). The customer sees "On the way" with his name and phone.
