#!/usr/bin/env bash
# End-to-end backend check (run in Termux:  pkg install curl jq)
# Usage: bash tools/e2e_check.sh SUPABASE_URL ANON_KEY ADMIN_EMAIL ADMIN_PASSWORD [EMAIL_DOMAIN]
# It does exactly the "Phone A -> Phone B" test against your real Supabase project:
#   customer signs up + places an order -> admin reads it -> admin sets CONFIRMED -> customer sees CONFIRMED.
set -u
[ $# -ge 4 ] || { echo "Usage: bash tools/e2e_check.sh SUPABASE_URL ANON_KEY ADMIN_EMAIL ADMIN_PASSWORD [EMAIL_DOMAIN]"; exit 1; }
for c in curl jq; do command -v $c >/dev/null || { echo "Install $c first:  pkg install $c"; exit 1; }; done
URL="${1%/}"; KEY="$2"; AEMAIL="$3"; APASS="$4"; DOMAIN="${5:-gmail.com}"
H=(-H "apikey: $KEY" -H "Content-Type: application/json")
FAILED=0
pass() { echo "  PASS: $1"; }
fail() { echo "  FAIL: $1"; FAILED=1; }
PHONE="9$(printf '%09d' $(( (RANDOM * 32768 + RANDOM) % 1000000000 )))"

echo "== PHONE A: customer $PHONE signs up"
SIGNUP=$(curl -s "${H[@]}" -X POST "$URL/auth/v1/signup" -d "{\"email\":\"$PHONE@$DOMAIN\",\"password\":\"test1234\",\"data\":{\"name\":\"E2E Test\",\"phone\":\"$PHONE\"}}")
CT=$(echo "$SIGNUP" | jq -r '.access_token // empty')
[ -n "$CT" ] || { echo "  FAIL: no token. Is 'Confirm email' turned OFF in Supabase? Response: $SIGNUP"; exit 1; }
pass "customer account created in the cloud"

echo "== PHONE A: places order (2 kg rice, 1 litre oil)"
ITEMS='[{"name":"Rice","qty_label":"2 kg","qty_unknown":false,"price":150,"product_id":null},{"name":"Oil","qty_label":"1 litre","qty_unknown":false,"price":120,"product_id":null}]'
OID=$(curl -s "${H[@]}" -H "Authorization: Bearer $CT" -X POST "$URL/rest/v1/rpc/place_order" \
  -d "{\"p_fulfillment\":\"DELIVERY\",\"p_name\":\"E2E Test\",\"p_phone\":\"$PHONE\",\"p_address\":\"12 Test Street, Test Town\",\"p_payment\":\"CASH\",\"p_client_ref\":\"e2e-$PHONE\",\"p_items\":$ITEMS}")
[[ "$OID" =~ ^[0-9]+$ ]] || { echo "  FAIL: place_order returned: $OID  (did you run supabase/schema.sql?)"; exit 1; }
pass "order saved in the cloud, id=$OID"

echo "== PHONE B: admin logs in and opens Orders"
AT=$(curl -s "${H[@]}" -X POST "$URL/auth/v1/token?grant_type=password" -d "{\"email\":\"$AEMAIL\",\"password\":\"$APASS\"}" | jq -r '.access_token // empty')
[ -n "$AT" ] || { echo "  FAIL: admin login failed (check email/password, and that the user is confirmed)"; exit 1; }
ORDER=$(curl -s "${H[@]}" -H "Authorization: Bearer $AT" "$URL/rest/v1/orders?id=eq.$OID&select=*,order_items(*)")
echo "$ORDER" | jq '.[0] | {order_no, customer_name, phone, fulfillment, address, payment, subtotal, delivery_fee, status, items: [.order_items[] | {name, qty_label, price}]}'
[ "$(echo "$ORDER" | jq '.[0].order_items | length')" = "2" ] && pass "admin sees both items" || fail "items missing"
[ "$(echo "$ORDER" | jq '.[0].subtotal == 270')" = "true" ] && pass "subtotal = 270" || fail "subtotal wrong"
[ "$(echo "$ORDER" | jq '.[0].delivery_fee == 0')" = "true" ] && pass "delivery = 0" || fail "delivery not 0"
[ "$(echo "$ORDER" | jq -r '.[0].payment')" = "CASH" ] && pass "payment method = CASH" || fail "payment wrong"

echo "== PHONE B: admin sets status to Confirmed"
R=$(curl -s -X PATCH "${H[@]}" -H "Authorization: Bearer $AT" -H "Prefer: return=representation" "$URL/rest/v1/orders?id=eq.$OID" -d '{"status":"CONFIRMED"}')
[ "$(echo "$R" | jq -r '.[0].status')" = "CONFIRMED" ] && pass "status saved" || fail "admin could not update status: $R"

echo "== PHONE A: refreshes orders"
S=$(curl -s "${H[@]}" -H "Authorization: Bearer $CT" "$URL/rest/v1/orders?id=eq.$OID&select=status" | jq -r '.[0].status')
[ "$S" = "CONFIRMED" ] && pass "customer sees status: $S" || fail "customer sees: $S"

echo "== SECURITY: customer must NOT be able to change status or see other orders"
R=$(curl -s -X PATCH "${H[@]}" -H "Authorization: Bearer $CT" -H "Prefer: return=representation" "$URL/rest/v1/orders?id=eq.$OID" -d '{"status":"DELIVERED"}')
[ "$(echo "$R" | jq 'length')" = "0" ] && pass "customer cannot change status" || fail "customer changed a status!"
N=$(curl -s "${H[@]}" -H "Authorization: Bearer $CT" "$URL/rest/v1/orders?select=id" | jq 'length')
[ "$N" = "1" ] && pass "customer sees only their own order" || fail "customer sees $N orders"

echo
[ $FAILED = 0 ] && echo "ALL CHECKS PASSED - orders are shared through Supabase." || echo "SOME CHECKS FAILED - see above."
echo "(Test customer $PHONE and its order remain in your database; delete them in the Supabase dashboard if you like.)"
