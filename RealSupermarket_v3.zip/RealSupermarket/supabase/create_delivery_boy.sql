-- =====================================================================
-- Creates the FIRST delivery boy account. Run AFTER supabase/schema.sql.
-- (Safe to run again. To add more delivery boys later, use
--  Admin > Delivery tab > "Add delivery boy" inside the app.)
--
--   Login ID : deliveryboy123   (type this in the "Mobile number or email" box)
--   Password : delivery123
--
-- The app turns the login ID into deliveryboy123@gmail.com behind the scenes.
-- If you set the CUSTOMER_EMAIL_DOMAIN secret to something other than gmail.com,
-- change the domain in v_email below to match.
--
-- Change the password after the first login: Delivery panel > Profile.
-- =====================================================================
create extension if not exists pgcrypto;

do $$
declare
  v_email text := 'deliveryboy123@gmail.com';
  v_pass  text := 'delivery123';
  v_name  text := 'Delivery Boy';
  v_phone text := '9000000001';
  v_id    uuid;
begin
  select id into v_id from auth.users where email = v_email;

  if v_id is null then
    v_id := gen_random_uuid();
    insert into auth.users (
      instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
      raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
      confirmation_token, recovery_token, email_change_token_new, email_change
    ) values (
      '00000000-0000-0000-0000-000000000000', v_id, 'authenticated', 'authenticated', v_email,
      crypt(v_pass, gen_salt('bf')), now(),
      '{"provider":"email","providers":["email"]}'::jsonb,
      jsonb_build_object('name', v_name, 'phone', v_phone),
      now(), now(), '', '', '', ''
    );
    insert into auth.identities (id, user_id, provider_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
    values (gen_random_uuid(), v_id, v_id::text,
            jsonb_build_object('sub', v_id::text, 'email', v_email, 'email_verified', true),
            'email', now(), now(), now());
  end if;

  -- the sign-up trigger already made a CUSTOMER profile: promote it
  insert into public.profiles (id, name, phone, role) values (v_id, v_name, v_phone, 'delivery')
  on conflict (id) do update set role = 'delivery', name = excluded.name, phone = excluded.phone;
end $$;

select p.name, p.phone, p.role, u.email
from public.profiles p join auth.users u on u.id = p.id
where p.role = 'delivery';
